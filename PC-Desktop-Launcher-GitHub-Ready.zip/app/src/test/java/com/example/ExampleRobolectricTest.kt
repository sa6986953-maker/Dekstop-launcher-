package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.LauncherDatabase
import com.example.data.model.ExplorerRootSection
import com.example.data.repository.DesktopRepository
import com.example.data.repository.FileExplorerRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `app name matches PC Desktop Launcher`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PC Desktop Launcher", appName)
    }

    @Test
    fun `manifest registers HOME launcher intent filter`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            addCategory(Intent.CATEGORY_DEFAULT)
        }
        val resolved = context.packageManager.queryIntentActivities(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
        val hasLauncherActivity = resolved.any {
            it.activityInfo.packageName == context.packageName &&
                it.activityInfo.name == MainActivity::class.java.name
        }
        assertTrue("MainActivity must be registered as a valid Android HOME launcher", hasLauncherActivity)
    }

    @Test
    fun `desktop repository seeds defaults and supports recycle bin restore`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = DesktopRepository(db.launcherDao())
            repo.ensureSeeded(emptyList())
            val seeded = repo.desktopItems.first()
            assertTrue(seeded.any { it.id == "sys_this_pc" })
            assertTrue(seeded.any { it.id == "sys_pc_settings" })
            assertTrue(seeded.any { it.id == "sys_recycle_bin" })

            repo.createDesktopFolder("Projects")
            val afterCreate = repo.desktopItems.first()
            val folder = afterCreate.first { it.title == "Projects" }

            repo.moveToRecycleBin(folder)
            val bin = repo.recycleBinItems.first()
            assertEquals(1, bin.size)
            assertEquals("Projects", bin.first().title)

            repo.restoreFromRecycleBin(bin.first())
            val afterRestore = repo.desktopItems.first()
            assertTrue(afterRestore.any { it.title == "Projects" })
            assertTrue(repo.recycleBinItems.first().isEmpty())
        } finally {
            db.close()
        }
    }

    @Test
    fun `file explorer repository creates lists renames and deletes workspace items`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = Room.inMemoryDatabaseBuilder(context, LauncherDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        try {
            val repo = FileExplorerRepository(context, db.launcherDao())
            repo.ensureWorkspaceSeeded()
            val docsPath = repo.getSectionPath(ExplorerRootSection.DOCUMENTS)

            repo.createFolder(docsPath, "TestDir", isSaf = false).getOrThrow()
            val createdPath = repo.createTextFile(docsPath, "Draft.txt", "Hello PC", isSaf = false).getOrThrow()
            val nodes = repo.listLocalDirectory(docsPath)
            assertTrue(nodes.any { it.isDirectory && it.name == "TestDir" })
            val fileNode = nodes.first { !it.isDirectory && it.pathOrUri == createdPath }

            val readBack = repo.readTextFile(fileNode.pathOrUri, isSaf = false).getOrThrow()
            assertEquals("Hello PC", readBack)

            repo.renameNode(fileNode, "Renamed.txt").getOrThrow()
            val afterRename = repo.listLocalDirectory(docsPath)
            val renamedNode = afterRename.first { it.name == "Renamed.txt" }

            repo.deleteNode(renamedNode).getOrThrow()
            val afterDelete = repo.listLocalDirectory(docsPath)
            assertTrue(afterDelete.none { it.name == "Renamed.txt" })
        } finally {
            db.close()
        }
    }
}
