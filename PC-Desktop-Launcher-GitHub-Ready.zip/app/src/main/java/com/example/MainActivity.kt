package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.example.ui.PcDesktopScreen
import com.example.ui.viewmodel.LauncherViewModel

class MainActivity : ComponentActivity() {

    private val launcherViewModel: LauncherViewModel by viewModels()

    private val homeRoleLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        launcherViewModel.refreshSystemStatus()
        if (result.resultCode != RESULT_OK) {
            // If RoleManager dialog was dismissed or unsupported on OEM, open Android Default Home settings directly
            if (!launcherViewModel.systemStatus.value.isDefaultLauncher) {
                launcherViewModel.openDefaultHomeSettings()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            PcDesktopScreen(
                viewModel = launcherViewModel,
                onRequestDefaultHome = { requestDefaultHomeLauncher() },
                onExitLauncher = {
                    if (!launcherViewModel.systemStatus.value.isDefaultLauncher) {
                        finish()
                    } else {
                        launcherViewModel.openDefaultHomeSettings()
                    }
                }
            )
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.hasCategory(Intent.CATEGORY_HOME)) {
            launcherViewModel.onHomePressed()
        }
    }

    override fun onResume() {
        super.onResume()
        launcherViewModel.refreshSystemStatus()
    }

    private fun requestDefaultHomeLauncher() {
        val roleIntent = launcherViewModel.createRequestHomeRoleIntent()
        if (roleIntent != null) {
            runCatching {
                homeRoleLauncher.launch(roleIntent)
            }.onFailure {
                launcherViewModel.openDefaultHomeSettings()
            }
        } else {
            launcherViewModel.openDefaultHomeSettings()
        }
    }
}
