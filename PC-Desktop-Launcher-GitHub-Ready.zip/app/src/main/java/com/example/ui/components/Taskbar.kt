package com.example.ui.components

import android.provider.Settings
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.VolumeOff
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.BatteryFull
import androidx.compose.material.icons.rounded.BatteryStd
import androidx.compose.material.icons.rounded.Bluetooth
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PinnedAppEntity
import com.example.data.model.DesktopWindow
import com.example.data.model.InstalledApp
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.data.model.TaskbarPosition
import com.example.data.model.WindowType
import com.example.ui.theme.FolderAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun WindowsTaskbar(
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    pinnedApps: List<PinnedAppEntity>,
    installedApps: List<InstalledApp>,
    openWindows: List<DesktopWindow>,
    activeWindowId: String?,
    startMenuOpen: Boolean,
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    val taskbarPinned = remember(pinnedApps) { pinnedApps.filter { it.pinnedToTaskbar } }
    val barBg = pcPalette.taskbarBase.copy(alpha = settings.taskbarTransparency.coerceIn(0.35f, 0.98f))
    val barHeight = settings.taskbarSize.heightDp.dp
    val iconSize = settings.taskbarSize.iconDp.dp
    val isTop = settings.taskbarPosition == TaskbarPosition.TOP

    val insetModifier = if (isTop) {
        Modifier.windowInsetsPadding(WindowInsets.statusBars)
    } else {
        Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxWidth()
            .background(barBg)
            .then(insetModifier)
            .border(width = 0.5.dp, color = pcPalette.windowBorder)
    ) {
        val isWide = maxWidth >= 560.dp

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .height(barHeight)
                .padding(horizontal = 8.dp)
        ) {
            // Left/Center Pinned & Active Windows Section
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .horizontalScroll(rememberScrollState())
            ) {
                // Start Button
                TaskbarActionTile(
                    isActive = startMenuOpen,
                    isFocused = startMenuOpen,
                    onClick = { viewModel.toggleStartMenu(focusSearch = false) },
                    modifier = Modifier.testTag("start_button")
                ) {
                    WindowsLogoIcon(size = iconSize)
                }

                // Search Button / Pill
                if (settings.showTaskbarSearch) {
                    if (isWide) {
                        Surface(
                            shape = RoundedCornerShape(18.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                            modifier = Modifier
                                .height((settings.taskbarSize.heightDp - 14).dp)
                                .widthIn(min = 140.dp, max = 210.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .clickable { viewModel.toggleStartMenu(focusSearch = true) }
                                .testTag("taskbar_search_button")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Search,
                                    contentDescription = "Search",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Search",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                            }
                        }
                    } else {
                        TaskbarActionTile(
                            isActive = false,
                            isFocused = false,
                            onClick = { viewModel.toggleStartMenu(focusSearch = true) },
                            modifier = Modifier.testTag("taskbar_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.size(iconSize)
                            )
                        }
                    }
                }

                // Built-in File Explorer quick pin if not already in openWindows
                val explorerOpen = openWindows.any { it.type == WindowType.FILE_EXPLORER }
                if (!explorerOpen) {
                    TaskbarActionTile(
                        isActive = false,
                        isFocused = false,
                        onClick = { viewModel.openWindow(WindowType.FILE_EXPLORER, "This PC") },
                        modifier = Modifier.testTag("taskbar_explorer_pin")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Folder,
                            contentDescription = "File Explorer",
                            tint = FolderAmber,
                            modifier = Modifier.size(iconSize)
                        )
                    }
                }

                // Pinned Android Apps
                taskbarPinned.forEach { pin ->
                    var showMenu by remember { mutableStateOf(false) }
                    Box {
                        TaskbarActionTile(
                            isActive = false,
                            isFocused = false,
                            onClick = {
                                viewModel.launchPackageShortcut(pin.packageName, pin.activityName, pin.label)
                            },
                            onLongClick = { showMenu = true },
                            modifier = Modifier.testTag("taskbar_pin_${pin.packageName}")
                        ) {
                            AppPackageIcon(
                                packageName = pin.packageName,
                                activityName = pin.activityName,
                                contentDescription = pin.label,
                                viewModel = viewModel,
                                size = iconSize
                            )
                        }
                        DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Open ${pin.label}") },
                                onClick = {
                                    showMenu = false
                                    viewModel.launchPackageShortcut(pin.packageName, pin.activityName, pin.label)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Unpin from Taskbar") },
                                leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
                                onClick = {
                                    showMenu = false
                                    val app = installedApps.firstOrNull { it.componentKey == pin.componentKey }
                                        ?: InstalledApp(pin.packageName, pin.activityName, pin.label)
                                    viewModel.togglePinToTaskbar(app)
                                }
                            )
                        }
                    }
                }

                // Open / Minimized Window Indicators
                openWindows.forEach { win ->
                    var showWinMenu by remember { mutableStateOf(false) }
                    val isFocused = !win.isMinimized && win.id == activeWindowId
                    Box {
                        TaskbarActionTile(
                            isActive = true,
                            isFocused = isFocused,
                            onClick = { viewModel.toggleMinimizeFromTaskbar(win.id) },
                            onLongClick = { showWinMenu = true },
                            modifier = Modifier.testTag("taskbar_window_${win.type.name}")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = windowTypeIcon(win.type),
                                    contentDescription = win.title,
                                    tint = windowTypeTint(win.type, pcPalette.accent),
                                    modifier = Modifier.size(iconSize)
                                )
                                if (isWide) {
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = win.title,
                                        style = MaterialTheme.typography.labelMedium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.widthIn(max = 96.dp)
                                    )
                                }
                            }
                        }
                        DropdownMenu(expanded = showWinMenu, onDismissRequest = { showWinMenu = false }) {
                            DropdownMenuItem(
                                text = { Text(if (win.isMinimized) "Restore" else "Minimize") },
                                onClick = {
                                    showWinMenu = false
                                    viewModel.toggleMinimizeFromTaskbar(win.id)
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Close Window") },
                                leadingIcon = { Icon(Icons.Rounded.Close, contentDescription = null) },
                                onClick = {
                                    showWinMenu = false
                                    viewModel.closeWindow(win.id)
                                }
                            )
                        }
                    }
                }
            }

            // Right Notification Area (System Tray + Clock)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                // Quick Settings Trigger (Wi-Fi + Volume + Battery)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.toggleQuickSettings() }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("system_tray_button")
                ) {
                    Icon(
                        imageVector = when {
                            systemStatus.wifiConnected -> Icons.Rounded.Wifi
                            systemStatus.mobileConnected -> Icons.Rounded.SignalCellularAlt
                            else -> Icons.Rounded.WifiOff
                        },
                        contentDescription = "Network Status",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    Icon(
                        imageVector = if (systemStatus.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Sound Volume",
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = when {
                                systemStatus.isCharging -> Icons.Rounded.BatteryChargingFull
                                systemStatus.batteryPercent >= 90 -> Icons.Rounded.BatteryFull
                                else -> Icons.Rounded.BatteryStd
                            },
                            contentDescription = "Battery ${systemStatus.batteryPercent}%",
                            tint = if (systemStatus.batteryPercent <= 15 && !systemStatus.isCharging) {
                                MaterialTheme.colorScheme.error
                            } else {
                                MaterialTheme.colorScheme.onSurface
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        if (isWide) {
                            Spacer(Modifier.width(2.dp))
                            Text(
                                text = "${systemStatus.batteryPercent}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = JetBrainsMonoFamily
                            )
                        }
                    }
                }

                // Live Clock & Date Trigger
                val dateObj = remember(systemStatus.currentTimeMillis) { Date(systemStatus.currentTimeMillis) }
                val timeStr = remember(systemStatus.currentTimeMillis) {
                    SimpleDateFormat("HH:mm", Locale.getDefault()).format(dateObj)
                }
                val dateStr = remember(systemStatus.currentTimeMillis) {
                    SimpleDateFormat("M/d", Locale.getDefault()).format(dateObj)
                }

                Column(
                    horizontalAlignment = Alignment.End,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { viewModel.toggleCalendarFlyout() }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("taskbar_clock_button")
                ) {
                    Text(
                        text = timeStr,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = JetBrainsMonoFamily
                    )
                    if (settings.taskbarSize.heightDp >= 52) {
                        Text(
                            text = dateStr,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontFamily = JetBrainsMonoFamily
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TaskbarActionTile(
    isActive: Boolean,
    isFocused: Boolean,
    onClick: () -> Unit,
    onLongClick: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .height(42.dp)
            .widthIn(min = 44.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(
                if (isFocused) pcPalette.hoverHighlight else Color.Transparent
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = 8.dp)
    ) {
        content()
        if (isActive) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 2.dp)
                    .width(if (isFocused) 18.dp else 8.dp)
                    .height(3.dp)
                    .clip(CircleShape)
                    .background(
                        if (isFocused) pcPalette.accent
                        else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                    )
            )
        }
    }
}

@Composable
fun QuickSettingsFlyout(
    systemStatus: SystemStatus,
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = pcPalette.flyoutSurface,
        tonalElevation = 12.dp,
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(min = 280.dp, max = 350.dp)
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(16.dp))
            .testTag("quick_settings_flyout")
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(16.dp)
        ) {
            Text("Quick Settings", style = MaterialTheme.typography.titleMedium)

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                QuickTileButton(
                    icon = if (systemStatus.wifiConnected) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                    label = if (systemStatus.wifiConnected) "Wi-Fi On" else "Wi-Fi",
                    active = systemStatus.wifiConnected || systemStatus.wifiEnabled,
                    onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_WIFI_SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
                QuickTileButton(
                    icon = Icons.Rounded.Bluetooth,
                    label = if (systemStatus.bluetoothEnabled) "BT On" else "Bluetooth",
                    active = systemStatus.bluetoothEnabled,
                    onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_BLUETOOTH_SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
                QuickTileButton(
                    icon = Icons.Rounded.BrightnessMedium,
                    label = "Display",
                    active = false,
                    onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_DISPLAY_SETTINGS) },
                    modifier = Modifier.weight(1f)
                )
            }

            // Real Media Volume Slider
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.toggleMute() }) {
                    Icon(
                        imageVector = if (systemStatus.isMuted) Icons.AutoMirrored.Rounded.VolumeOff else Icons.AutoMirrored.Rounded.VolumeUp,
                        contentDescription = "Mute Toggle"
                    )
                }
                Slider(
                    value = systemStatus.volumePercent / 100f,
                    onValueChange = { frac -> viewModel.setMediaVolumePercent((frac * 100).toInt()) },
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "${systemStatus.volumePercent}%",
                    style = MaterialTheme.typography.labelMedium,
                    fontFamily = JetBrainsMonoFamily,
                    modifier = Modifier.width(38.dp),
                    textAlign = TextAlign.End
                )
            }

            HorizontalDivider(color = pcPalette.windowBorder)

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (systemStatus.isCharging) Icons.Rounded.BatteryChargingFull else Icons.Rounded.BatteryFull,
                        contentDescription = null,
                        tint = pcPalette.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "${systemStatus.batteryPercent}%${if (systemStatus.isCharging) " Charging" else ""}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onRequestDefaultHome) {
                        Icon(Icons.Rounded.Home, contentDescription = "Default Home Launcher")
                    }
                    IconButton(onClick = { viewModel.openWindow(WindowType.PC_SETTINGS, "PC Settings") }) {
                        Icon(Icons.Rounded.Settings, contentDescription = "PC Settings")
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickTileButton(
    icon: ImageVector,
    label: String,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (active) pcPalette.accent else pcPalette.windowCard,
        modifier = modifier
            .height(64.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(20.dp)
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = if (active) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
fun CalendarFlyout(
    currentTimeMillis: Long,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    val cal = remember(currentTimeMillis) {
        Calendar.getInstance().apply { timeInMillis = currentTimeMillis }
    }
    val todayDay = cal.get(Calendar.DAY_OF_MONTH)
    val monthHeader = remember(currentTimeMillis) {
        SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault()).format(Date(currentTimeMillis))
    }
    val monthTitle = remember(currentTimeMillis) {
        SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date(currentTimeMillis))
    }

    val firstDayCal = remember(currentTimeMillis) {
        (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }
    }
    val offsetDays = firstDayCal.get(Calendar.DAY_OF_WEEK) - 1
    val daysInMonth = firstDayCal.getActualMaximum(Calendar.DAY_OF_MONTH)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = pcPalette.flyoutSurface,
        tonalElevation = 12.dp,
        shadowElevation = 16.dp,
        modifier = modifier
            .widthIn(min = 280.dp, max = 330.dp)
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(16.dp))
            .testTag("calendar_flyout")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = monthHeader,
                style = MaterialTheme.typography.titleSmall,
                color = pcPalette.accent,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(8.dp))
            Text(text = monthTitle, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(10.dp))

            val weekdays = listOf("Su", "Mo", "Tu", "We", "Th", "Fr", "Sa")
            Row(modifier = Modifier.fillMaxWidth()) {
                weekdays.forEach { d ->
                    Text(
                        text = d,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            Spacer(Modifier.height(6.dp))

            val totalCells = offsetDays + daysInMonth
            val rows = (totalCells + 6) / 7
            for (r in 0 until rows) {
                Row(modifier = Modifier.fillMaxWidth()) {
                    for (c in 0 until 7) {
                        val cellIndex = r * 7 + c
                        val dayNum = cellIndex - offsetDays + 1
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .weight(1f)
                                .height(32.dp)
                                .padding(2.dp)
                                .clip(CircleShape)
                                .background(
                                    if (dayNum == todayDay) pcPalette.accent else Color.Transparent
                                )
                        ) {
                            if (dayNum in 1..daysInMonth) {
                                Text(
                                    text = dayNum.toString(),
                                    fontSize = 12.sp,
                                    color = if (dayNum == todayDay) {
                                        MaterialTheme.colorScheme.onPrimary
                                    } else {
                                        MaterialTheme.colorScheme.onSurface
                                    },
                                    fontWeight = if (dayNum == todayDay) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

fun windowTypeIcon(type: WindowType): ImageVector = when (type) {
    WindowType.FILE_EXPLORER -> Icons.Rounded.Folder
    WindowType.PC_SETTINGS -> Icons.Rounded.Settings
    WindowType.RECYCLE_BIN -> Icons.Rounded.DeleteOutline
    WindowType.DESKTOP_FOLDER -> Icons.Rounded.Folder
    WindowType.NOTEPAD -> Icons.Rounded.Description
    WindowType.TASK_MONITOR -> Icons.Rounded.MonitorHeart
}

fun windowTypeTint(type: WindowType, accent: Color): Color = when (type) {
    WindowType.FILE_EXPLORER, WindowType.DESKTOP_FOLDER -> FolderAmber
    WindowType.RECYCLE_BIN -> Color(0xFF38BDF8)
    WindowType.TASK_MONITOR -> Color(0xFF10B981)
    WindowType.PC_SETTINGS -> Color(0xFF94A3B8)
    WindowType.NOTEPAD -> accent
}
