package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Immutable
data class PcSurfacePalette(
    val isDark: Boolean,
    val accent: Color,
    val windowSurface: Color,
    val windowHeader: Color,
    val windowCard: Color,
    val windowBorder: Color,
    val flyoutSurface: Color,
    val taskbarBase: Color,
    val desktopLabelScrim: Color,
    val hoverHighlight: Color
)

val LocalPcPalette = staticCompositionLocalOf {
    PcSurfacePalette(
        isDark = true,
        accent = Color(0xFF60CDFF),
        windowSurface = DarkSurface,
        windowHeader = Color(0xFF181C24),
        windowCard = DarkSurfaceVariant,
        windowBorder = DarkBorder,
        flyoutSurface = Color(0xEB1D222C),
        taskbarBase = TaskbarDarkBase,
        desktopLabelScrim = Color(0x66000000),
        hoverHighlight = Color(0x1FFFFFFF)
    )
}

private val PcShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
    extraLarge = RoundedCornerShape(20.dp)
)

@Composable
fun PcLauncherTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    accentPreset: AccentPreset = AccentPreset.WINDOWS_BLUE,
    content: @Composable () -> Unit
) {
    val accent = if (darkTheme) accentPreset.dark else accentPreset.light

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color(0xFF00203A),
            primaryContainer = accent.copy(alpha = 0.22f),
            onPrimaryContainer = Color.White,
            secondary = Color(0xFF94A3B8),
            onSecondary = Color(0xFF0F172A),
            background = DarkBackground,
            onBackground = DarkTextPrimary,
            surface = DarkSurface,
            onSurface = DarkTextPrimary,
            surfaceVariant = DarkSurfaceVariant,
            onSurfaceVariant = DarkTextSecondary,
            outline = DarkBorder,
            error = DangerRed,
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.14f),
            onPrimaryContainer = Color(0xFF0B2545),
            secondary = Color(0xFF475569),
            onSecondary = Color.White,
            background = LightBackground,
            onBackground = LightTextPrimary,
            surface = LightSurface,
            onSurface = LightTextPrimary,
            surfaceVariant = LightSurfaceVariant,
            onSurfaceVariant = LightTextSecondary,
            outline = LightBorder,
            error = DangerRed,
            onError = Color.White
        )
    }

    val pcPalette = if (darkTheme) {
        PcSurfacePalette(
            isDark = true,
            accent = accent,
            windowSurface = Color(0xF51F242D),
            windowHeader = Color(0xFF171B22),
            windowCard = Color(0xFF282E3A),
            windowBorder = Color(0x2BFFFFFF),
            flyoutSurface = Color(0xEE1B2029),
            taskbarBase = TaskbarDarkBase,
            desktopLabelScrim = Color(0x70000000),
            hoverHighlight = Color(0x1CFFFFFF)
        )
    } else {
        PcSurfacePalette(
            isDark = false,
            accent = accent,
            windowSurface = Color(0xF7F8FAFC),
            windowHeader = Color(0xFFEEF2F6),
            windowCard = Color(0xFFFFFFFF),
            windowBorder = Color(0x1F0F172A),
            flyoutSurface = Color(0xF2F4F7FA),
            taskbarBase = TaskbarLightBase,
            desktopLabelScrim = Color(0x66000000),
            hoverHighlight = Color(0x14000000)
        )
    }

    CompositionLocalProvider(LocalPcPalette provides pcPalette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            shapes = PcShapes,
            content = content
        )
    }
}
