package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.TaskbarPosition
import com.example.data.model.ThemeMode
import com.example.data.model.WindowType
import com.example.ui.components.CalendarFlyout
import com.example.ui.components.DesktopWorkspace
import com.example.ui.components.QuickSettingsFlyout
import com.example.ui.components.WallpaperLayer
import com.example.ui.components.WindowFrame
import com.example.ui.components.WindowsStartMenu
import com.example.ui.components.WindowsTaskbar
import com.example.ui.theme.AccentPreset
import com.example.ui.theme.LocalPcPalette
import com.example.ui.theme.PcLauncherTheme
import com.example.ui.viewmodel.LauncherViewModel
import com.example.ui.windows.DesktopFolderWindow
import com.example.ui.windows.FileExplorerWindow
import com.example.ui.windows.NotepadWindow
import com.example.ui.windows.PcSettingsWindow
import com.example.ui.windows.RecycleBinWindow
import com.example.ui.windows.TaskMonitorWindow
import kotlinx.coroutines.delay

@Composable
fun PcDesktopScreen(
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit,
    onExitLauncher: () -> Unit
) {
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val desktopItems by viewModel.desktopItems.collectAsStateWithLifecycle()
    val recycleBinItems by viewModel.recycleBinItems.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val pinnedApps by viewModel.pinnedApps.collectAsStateWithLifecycle()
    val recentApps by viewModel.recentInstalledApps.collectAsStateWithLifecycle()
    val safMounts by viewModel.safMounts.collectAsStateWithLifecycle()
    val systemStatus by viewModel.systemStatus.collectAsStateWithLifecycle()
    val openWindows by viewModel.openWindows.collectAsStateWithLifecycle()
    val activeWindowId by viewModel.activeWindowId.collectAsStateWithLifecycle()
    val startMenuOpen by viewModel.startMenuOpen.collectAsStateWithLifecycle()
    val startMenuFocusSearch by viewModel.startMenuFocusSearch.collectAsStateWithLifecycle()
    val quickSettingsOpen by viewModel.quickSettingsOpen.collectAsStateWithLifecycle()
    val calendarFlyoutOpen by viewModel.calendarFlyoutOpen.collectAsStateWithLifecycle()
    val powerMenuOpen by viewModel.powerMenuOpen.collectAsStateWithLifecycle()
    val movingItemId by viewModel.movingDesktopItemId.collectAsStateWithLifecycle()
    val explorerState by viewModel.explorerState.collectAsStateWithLifecycle()
    val notepadSessions by viewModel.notepadSessions.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    var showDefaultHomeBanner by remember { mutableStateOf(true) }

    LaunchedEffect(statusMessage) {
        if (statusMessage != null) {
            delay(2600L)
            viewModel.clearStatusMessage()
        }
    }

    val isDark = when (settings.themeMode) {
        ThemeMode.DARK -> true
        ThemeMode.LIGHT -> false
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val hasAnyOverlay = startMenuOpen || quickSettingsOpen || calendarFlyoutOpen || powerMenuOpen
    val hasVisibleWindow = openWindows.any { !it.isMinimized }

    // Proper Home launcher Back handling: close overlays -> cancel move -> close top window -> stay on Home if default launcher
    BackHandler(enabled = hasAnyOverlay || movingItemId != null || hasVisibleWindow || systemStatus.isDefaultLauncher) {
        when {
            hasAnyOverlay -> viewModel.closeAllFlyouts()
            movingItemId != null -> viewModel.cancelMovingDesktopItem()
            hasVisibleWindow -> viewModel.closeTopActiveWindowIfAny()
            else -> { /* Stay on Desktop when acting as Android Home launcher */ }
        }
    }

    PcLauncherTheme(
        darkTheme = isDark,
        accentPreset = AccentPreset.fromKey(settings.accentKey)
    ) {
        val pcPalette = LocalPcPalette.current
        val animDuration = if (settings.animationsEnabled) settings.animationSpeed.durationMs else 0
        val taskbarAtTop = settings.taskbarPosition == TaskbarPosition.TOP

        Box(modifier = Modifier.fillMaxSize()) {
            // Full-bleed edge-to-edge desktop wallpaper
            WallpaperLayer(settings = settings)

            Column(modifier = Modifier.fillMaxSize()) {
                if (taskbarAtTop) {
                    WindowsTaskbar(
                        settings = settings,
                        systemStatus = systemStatus,
                        pinnedApps = pinnedApps,
                        installedApps = installedApps,
                        openWindows = openWindows,
                        activeWindowId = activeWindowId,
                        startMenuOpen = startMenuOpen,
                        viewModel = viewModel
                    )
                }

                // Main Desktop + Window Area
                val workspaceInsetModifier = if (taskbarAtTop) {
                    Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                } else {
                    Modifier.windowInsetsPadding(WindowInsets.statusBars)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .then(workspaceInsetModifier)
                ) {
                    DesktopWorkspace(
                        desktopItems = desktopItems,
                        installedApps = installedApps,
                        recycleBinCount = recycleBinItems.size,
                        settings = settings,
                        systemStatus = systemStatus,
                        movingItemId = movingItemId,
                        showDefaultHomeBanner = showDefaultHomeBanner,
                        onDismissDefaultHomeBanner = { showDefaultHomeBanner = false },
                        onRequestDefaultHome = onRequestDefaultHome,
                        viewModel = viewModel
                    )

                    // Open Multi-Window Panels ordered by zIndex
                    val sortedWindows = remember(openWindows) {
                        openWindows.filterNot { it.isMinimized }.sortedBy { it.zIndex }
                    }
                    sortedWindows.forEach { win ->
                        WindowFrame(
                            window = win,
                            isActive = win.id == activeWindowId,
                            onFocus = { viewModel.focusWindow(win.id) },
                            onMinimize = { viewModel.minimizeWindow(win.id) },
                            onToggleMaximize = { viewModel.toggleMaximizeWindow(win.id) },
                            onClose = { viewModel.closeWindow(win.id) },
                            onMove = { dx, dy -> viewModel.moveWindow(win.id, dx, dy) },
                            onResize = { dw, dh -> viewModel.resizeWindow(win.id, dw, dh) }
                        ) {
                            when (win.type) {
                                WindowType.FILE_EXPLORER -> FileExplorerWindow(
                                    explorerState = explorerState,
                                    safMounts = safMounts,
                                    systemStatus = systemStatus,
                                    viewModel = viewModel
                                )
                                WindowType.PC_SETTINGS -> PcSettingsWindow(
                                    settings = settings,
                                    systemStatus = systemStatus,
                                    installedApps = installedApps,
                                    viewModel = viewModel,
                                    onRequestDefaultHome = onRequestDefaultHome
                                )
                                WindowType.RECYCLE_BIN -> RecycleBinWindow(
                                    items = recycleBinItems,
                                    viewModel = viewModel
                                )
                                WindowType.DESKTOP_FOLDER -> DesktopFolderWindow(
                                    folderId = win.folderId.orEmpty(),
                                    desktopItems = desktopItems,
                                    recycleBinCount = recycleBinItems.size,
                                    viewModel = viewModel
                                )
                                WindowType.NOTEPAD -> NotepadWindow(
                                    session = notepadSessions[win.id],
                                    viewModel = viewModel
                                )
                                WindowType.TASK_MONITOR -> TaskMonitorWindow(
                                    systemStatus = systemStatus,
                                    openWindows = openWindows,
                                    viewModel = viewModel
                                )
                            }
                        }
                    }

                    // Scrim when flyouts are open so tapping outside closes them
                    if (hasAnyOverlay) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .clickable(
                                    interactionSource = remember { MutableInteractionSource() },
                                    indication = null,
                                    onClick = { viewModel.closeAllFlyouts() }
                                )
                        )
                    }

                    // Start Menu Flyout
                    androidx.compose.animation.AnimatedVisibility(
                        visible = startMenuOpen,
                        enter = fadeIn(tween(animDuration)) + slideInVertically(tween(animDuration)) {
                            if (taskbarAtTop) -it / 4 else it / 4
                        },
                        exit = fadeOut(tween(animDuration)) + slideOutVertically(tween(animDuration)) {
                            if (taskbarAtTop) -it / 4 else it / 4
                        },
                        modifier = Modifier
                            .align(if (taskbarAtTop) Alignment.TopStart else Alignment.BottomStart)
                            .imePadding()
                            .padding(10.dp)
                    ) {
                        WindowsStartMenu(
                            installedApps = installedApps,
                            pinnedApps = pinnedApps,
                            recentApps = recentApps,
                            focusSearchOnOpen = startMenuFocusSearch,
                            powerMenuOpen = powerMenuOpen,
                            viewModel = viewModel,
                            onRequestDefaultHome = onRequestDefaultHome,
                            onExitLauncher = onExitLauncher
                        )
                    }

                    // Quick Settings Flyout
                    androidx.compose.animation.AnimatedVisibility(
                        visible = quickSettingsOpen,
                        enter = fadeIn(tween(animDuration)) + slideInVertically(tween(animDuration)) {
                            if (taskbarAtTop) -it / 4 else it / 4
                        },
                        exit = fadeOut(tween(animDuration)),
                        modifier = Modifier
                            .align(if (taskbarAtTop) Alignment.TopEnd else Alignment.BottomEnd)
                            .padding(10.dp)
                    ) {
                        QuickSettingsFlyout(
                            systemStatus = systemStatus,
                            viewModel = viewModel,
                            onRequestDefaultHome = onRequestDefaultHome
                        )
                    }

                    // Calendar Flyout
                    androidx.compose.animation.AnimatedVisibility(
                        visible = calendarFlyoutOpen,
                        enter = fadeIn(tween(animDuration)) + slideInVertically(tween(animDuration)) {
                            if (taskbarAtTop) -it / 4 else it / 4
                        },
                        exit = fadeOut(tween(animDuration)),
                        modifier = Modifier
                            .align(if (taskbarAtTop) Alignment.TopEnd else Alignment.BottomEnd)
                            .padding(10.dp)
                    ) {
                        CalendarFlyout(currentTimeMillis = systemStatus.currentTimeMillis)
                    }

                    // Status Notification Pill
                    androidx.compose.animation.AnimatedVisibility(
                        visible = statusMessage != null,
                        enter = fadeIn(tween(150)),
                        exit = fadeOut(tween(200)),
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 12.dp)
                    ) {
                        statusMessage?.let { msg ->
                            Surface(
                                shape = RoundedCornerShape(20.dp),
                                color = pcPalette.flyoutSurface,
                                tonalElevation = 10.dp,
                                shadowElevation = 8.dp
                            ) {
                                Text(
                                    text = msg,
                                    style = MaterialTheme.typography.labelMedium,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }

                if (!taskbarAtTop) {
                    WindowsTaskbar(
                        settings = settings,
                        systemStatus = systemStatus,
                        pinnedApps = pinnedApps,
                        installedApps = installedApps,
                        openWindows = openWindows,
                        activeWindowId = activeWindowId,
                        startMenuOpen = startMenuOpen,
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}
