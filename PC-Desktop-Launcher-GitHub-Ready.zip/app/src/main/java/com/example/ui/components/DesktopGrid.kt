package com.example.ui.components

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AutoAwesomeMosaic
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.OpenWith
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SortByAlpha
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.DpOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.data.model.InstalledApp
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.data.model.WallpaperPreset
import com.example.data.model.WindowType
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WallpaperLayer(
    settings: PcSettingsState,
    modifier: Modifier = Modifier
) {
    val customUri = settings.customWallpaperUri
    if (!customUri.isNullOrBlank()) {
        AsyncImage(
            model = Uri.parse(customUri),
            contentDescription = "Desktop Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize()
        )
        return
    }

    when (settings.wallpaperId) {
        WallpaperPreset.BLOOM.id -> Image(
            painter = painterResource(id = R.drawable.img_wallpaper_bloom),
            contentDescription = "Windows Bloom Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize()
        )
        WallpaperPreset.SUNRISE.id -> Image(
            painter = painterResource(id = R.drawable.img_wallpaper_sunrise),
            contentDescription = "Pearl Sunrise Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize()
        )
        WallpaperPreset.AURORA.id -> Image(
            painter = painterResource(id = R.drawable.img_wallpaper_aurora),
            contentDescription = "Northern Aurora Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize()
        )
        WallpaperPreset.SUNSET.id -> Image(
            painter = painterResource(id = R.drawable.img_wallpaper_sunset),
            contentDescription = "Dusk Dunes Wallpaper",
            contentScale = ContentScale.Crop,
            modifier = modifier.fillMaxSize()
        )
        WallpaperPreset.MIDNIGHT_MESH.id -> Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(Color(0xFF1E293B), Color(0xFF0F172A), Color(0xFF050811))
                    )
                )
        )
        else -> Box(
            modifier = modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(Color(0xFF0B3B6F), Color(0xFF08203E), Color(0xFF0F172A))
                    )
                )
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DesktopWorkspace(
    desktopItems: List<DesktopItem>,
    installedApps: List<InstalledApp>,
    recycleBinCount: Int,
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    movingItemId: String?,
    showDefaultHomeBanner: Boolean,
    onDismissDefaultHomeBanner: () -> Unit,
    onRequestDefaultHome: () -> Unit,
    viewModel: LauncherViewModel,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    var showDesktopMenu by remember { mutableStateOf(false) }
    var contextItem by remember { mutableStateOf<DesktopItem?>(null) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<DesktopItem?>(null) }
    var propertiesTarget by remember { mutableStateOf<DesktopItem?>(null) }

    val rootItems = remember(desktopItems) {
        desktopItems.filter { it.parentFolderId == null }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .combinedClickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = {
                    viewModel.closeAllFlyouts()
                    if (movingItemId != null) viewModel.cancelMovingDesktopItem()
                },
                onLongClick = {
                    viewModel.closeAllFlyouts()
                    showDesktopMenu = true
                }
            )
            .padding(horizontal = 10.dp, vertical = 10.dp)
    ) {
        val cellWidthDp = settings.iconSize.tileWidthDp.dp
        val cellHeightDp = (settings.iconSize.iconDp + 44).dp
        val maxCols = (maxWidth / cellWidthDp).toInt().coerceAtLeast(3)
        val maxRows = ((maxHeight - if (showDefaultHomeBanner && !systemStatus.isDefaultLauncher) 64.dp else 0.dp) / cellHeightDp)
            .toInt()
            .coerceAtLeast(4)

        // Move Mode grid overlay so user can tap any destination cell
        if (movingItemId != null) {
            for (c in 0 until maxCols) {
                for (r in 0 until maxRows) {
                    Box(
                        modifier = Modifier
                            .offset(x = cellWidthDp * c, y = cellHeightDp * r)
                            .size(width = cellWidthDp - 4.dp, height = cellHeightDp - 4.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(pcPalette.accent.copy(alpha = 0.08f))
                            .border(1.dp, pcPalette.accent.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
                            .clickable { viewModel.moveDesktopItemToGrid(movingItemId, c, r) }
                    )
                }
            }
        }

        // Desktop Clock Widget on right/top if enabled and space allows
        if (settings.showDesktopClock) {
            DesktopClockWidget(
                currentTimeMillis = systemStatus.currentTimeMillis,
                isLandscapeOrWide = maxCols >= 6,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(end = 8.dp, top = 4.dp)
            )
        }

        // Render Desktop Icons at their grid positions (clamped cleanly to screen size)
        val occupied = remember { mutableSetOf<Pair<Int, Int>>() }
        occupied.clear()

        rootItems.forEachIndexed { idx, item ->
            var col = item.gridCol.coerceIn(0, maxCols - 1)
            var row = item.gridRow.coerceIn(0, maxRows - 1)
            if ((col to row) in occupied || settings.autoArrangeGrid) {
                if (settings.autoArrangeGrid) {
                    col = (idx / maxRows).coerceAtMost(maxCols - 1)
                    row = idx % maxRows
                }
                while ((col to row) in occupied) {
                    row++
                    if (row >= maxRows) {
                        row = 0
                        col = (col + 1) % maxCols
                    }
                }
            }
            occupied.add(col to row)

            val isBeingMoved = movingItemId == item.id

            Box(
                modifier = Modifier
                    .offset(x = cellWidthDp * col, y = cellHeightDp * row)
                    .size(width = cellWidthDp, height = cellHeightDp)
            ) {
                DesktopIconTile(
                    item = item,
                    recycleBinCount = recycleBinCount,
                    settings = settings,
                    isSelected = isBeingMoved,
                    viewModel = viewModel,
                    onClick = { viewModel.openDesktopItem(item) },
                    onLongClick = { contextItem = item }
                )

                if (contextItem?.id == item.id) {
                    DesktopItemContextMenu(
                        item = item,
                        expanded = true,
                        installedApps = installedApps,
                        onDismiss = { contextItem = null },
                        onOpen = {
                            contextItem = null
                            viewModel.openDesktopItem(item)
                        },
                        onMove = {
                            contextItem = null
                            viewModel.startMovingDesktopItem(item.id)
                        },
                        onRename = {
                            contextItem = null
                            renameTarget = item
                        },
                        onPinToStart = { app ->
                            contextItem = null
                            viewModel.togglePinToStart(app)
                        },
                        onPinToTaskbar = { app ->
                            contextItem = null
                            viewModel.togglePinToTaskbar(app)
                        },
                        onAppInfo = { pkg ->
                            contextItem = null
                            viewModel.openAppInfo(pkg)
                        },
                        onDelete = {
                            contextItem = null
                            viewModel.moveDesktopItemToRecycleBin(item)
                        },
                        onEmptyRecycleBin = {
                            contextItem = null
                            viewModel.emptyRecycleBin()
                        },
                        onProperties = {
                            contextItem = null
                            propertiesTarget = item
                        }
                    )
                }
            }
        }

        // Empty Desktop Context Menu
        Box(modifier = Modifier.align(Alignment.Center)) {
            DropdownMenu(
                expanded = showDesktopMenu,
                onDismissRequest = { showDesktopMenu = false },
                offset = DpOffset(0.dp, 0.dp)
            ) {
                DropdownMenuItem(
                    text = { Text("New Folder") },
                    leadingIcon = { Icon(Icons.Rounded.CreateNewFolder, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        showNewFolderDialog = true
                    }
                )
                DropdownMenuItem(
                    text = { Text("New Text Document") },
                    leadingIcon = { Icon(Icons.Rounded.NoteAdd, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        showNewFileDialog = true
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("Auto-Arrange Icons") },
                    leadingIcon = { Icon(Icons.Rounded.AutoAwesomeMosaic, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        viewModel.autoArrangeDesktop(maxRows = maxRows, sortByName = false)
                    }
                )
                DropdownMenuItem(
                    text = { Text("Sort Icons by Name") },
                    leadingIcon = { Icon(Icons.Rounded.SortByAlpha, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        viewModel.autoArrangeDesktop(maxRows = maxRows, sortByName = true)
                    }
                )
                DropdownMenuItem(
                    text = { Text("Refresh Desktop") },
                    leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        viewModel.refreshDesktopAndApps()
                    }
                )
                HorizontalDivider()
                DropdownMenuItem(
                    text = { Text("Open File Explorer") },
                    leadingIcon = { Icon(Icons.Rounded.FolderOpen, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        viewModel.openWindow(WindowType.FILE_EXPLORER, "This PC")
                    }
                )
                DropdownMenuItem(
                    text = { Text("Personalize Wallpaper & Theme") },
                    leadingIcon = { Icon(Icons.Rounded.Palette, contentDescription = null) },
                    onClick = {
                        showDesktopMenu = false
                        viewModel.openWindow(WindowType.PC_SETTINGS, "PC Settings")
                    }
                )
            }
        }

        // Move Mode Banner
        AnimatedVisibility(
            visible = movingItemId != null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 6.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = pcPalette.flyoutSurface,
                tonalElevation = 6.dp,
                modifier = Modifier.border(1.dp, pcPalette.accent, RoundedCornerShape(24.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.OpenWith, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Tap a highlighted grid cell to move icon", style = MaterialTheme.typography.labelMedium)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { viewModel.cancelMovingDesktopItem() }) {
                        Text("Cancel")
                    }
                }
            }
        }

        // Default Home Launcher Prompt Banner (only shown if not default Home yet & not dismissed)
        AnimatedVisibility(
            visible = showDefaultHomeBanner && !systemStatus.isDefaultLauncher && movingItemId == null,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 8.dp)
        ) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = pcPalette.flyoutSurface,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .widthIn(max = 520.dp)
                    .fillMaxWidth()
                    .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(14.dp))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Home,
                        contentDescription = null,
                        tint = pcPalette.accent,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Set as Default Home Launcher",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Pressing Home will open this Windows desktop.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = onRequestDefaultHome,
                        modifier = Modifier.testTag("banner_set_default_home")
                    ) {
                        Text("Set Home", maxLines = 1)
                    }
                    IconButton(onClick = onDismissDefaultHomeBanner) {
                        Icon(Icons.Rounded.Close, contentDescription = "Dismiss")
                    }
                }
            }
        }
    }

    // Dialogs
    if (showNewFolderDialog) {
        TextInputDialog(
            title = "New Desktop Folder",
            label = "Folder name",
            initialValue = "New Folder",
            confirmLabel = "Create",
            onDismiss = { showNewFolderDialog = false },
            onConfirm = { name ->
                showNewFolderDialog = false
                viewModel.createDesktopFolder(name)
            }
        )
    }

    if (showNewFileDialog) {
        TextInputDialog(
            title = "New Text Document",
            label = "File name",
            initialValue = "Notes.txt",
            confirmLabel = "Create",
            onDismiss = { showNewFileDialog = false },
            onConfirm = { name ->
                showNewFileDialog = false
                viewModel.createDesktopTextFile(name)
            }
        )
    }

    renameTarget?.let { target ->
        TextInputDialog(
            title = "Rename Shortcut",
            label = "Name",
            initialValue = target.title,
            confirmLabel = "Rename",
            onDismiss = { renameTarget = null },
            onConfirm = { newName ->
                renameTarget = null
                viewModel.renameDesktopItem(target.id, newName)
            }
        )
    }

    propertiesTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { propertiesTarget = null },
            title = { Text("${target.title} Properties") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Type: ${target.type.name.replace('_', ' ')}", style = MaterialTheme.typography.bodyMedium)
                    Text("Grid Position: Column ${target.gridCol + 1}, Row ${target.gridRow + 1}", style = MaterialTheme.typography.bodyMedium)
                    target.targetPackage?.let {
                        Text("Package: $it", style = MaterialTheme.typography.bodySmall, fontFamily = JetBrainsMonoFamily)
                    }
                    target.targetPath?.let {
                        Text("Path: PC_User/$it", style = MaterialTheme.typography.bodySmall, fontFamily = JetBrainsMonoFamily)
                    }
                    Text("Created: ${formatTimestamp(target.createdAt)}", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = { propertiesTarget = null }) { Text("Close") }
            }
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DesktopIconTile(
    item: DesktopItem,
    recycleBinCount: Int,
    settings: PcSettingsState,
    isSelected: Boolean,
    viewModel: LauncherViewModel,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    val displayTitle = remember(item.title, settings.showFileExtensions, item.type) {
        if (!settings.showFileExtensions && item.type == DesktopItemType.FILE && item.title.contains('.')) {
            item.title.substringBeforeLast('.')
        } else {
            item.title
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .fillMaxSize()
            .padding(2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) pcPalette.accent.copy(alpha = 0.25f) else Color.Transparent)
            .then(
                if (isSelected) Modifier.border(1.5.dp, pcPalette.accent, RoundedCornerShape(10.dp))
                else Modifier
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            )
            .padding(horizontal = 4.dp, vertical = 4.dp)
            .testTag("desktop_icon_${item.id}")
    ) {
        DesktopItemIcon(
            item = item,
            recycleBinCount = recycleBinCount,
            viewModel = viewModel,
            size = settings.iconSize.iconDp.dp
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = displayTitle,
            color = Color.White,
            fontSize = settings.iconSize.fontSp.sp,
            lineHeight = (settings.iconSize.fontSp + 3).sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(pcPalette.desktopLabelScrim)
                .padding(horizontal = 4.dp, vertical = 1.dp)
        )
    }
}

@Composable
private fun DesktopItemContextMenu(
    item: DesktopItem,
    expanded: Boolean,
    installedApps: List<InstalledApp>,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onMove: () -> Unit,
    onRename: () -> Unit,
    onPinToStart: (InstalledApp) -> Unit,
    onPinToTaskbar: (InstalledApp) -> Unit,
    onAppInfo: (String) -> Unit,
    onDelete: () -> Unit,
    onEmptyRecycleBin: () -> Unit,
    onProperties: () -> Unit
) {
    val matchedApp = remember(item, installedApps) {
        item.targetPackage?.let { pkg -> installedApps.firstOrNull { it.packageName == pkg } }
    }
    val isCoreSystem = item.type == DesktopItemType.THIS_PC ||
        item.type == DesktopItemType.PC_SETTINGS ||
        item.type == DesktopItemType.RECYCLE_BIN

    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Open", fontWeight = FontWeight.SemiBold) },
            leadingIcon = { Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null) },
            onClick = onOpen
        )
        DropdownMenuItem(
            text = { Text("Move on Desktop") },
            leadingIcon = { Icon(Icons.Rounded.OpenWith, contentDescription = null) },
            onClick = onMove
        )
        DropdownMenuItem(
            text = { Text("Rename") },
            leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = null) },
            onClick = onRename
        )
        if (matchedApp != null) {
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Pin / Unpin Start") },
                leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
                onClick = { onPinToStart(matchedApp) }
            )
            DropdownMenuItem(
                text = { Text("Pin / Unpin Taskbar") },
                leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
                onClick = { onPinToTaskbar(matchedApp) }
            )
            DropdownMenuItem(
                text = { Text("App Info") },
                leadingIcon = { Icon(Icons.Rounded.Settings, contentDescription = null) },
                onClick = { onAppInfo(matchedApp.packageName) }
            )
        }
        if (item.type == DesktopItemType.RECYCLE_BIN) {
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Empty Recycle Bin") },
                leadingIcon = { Icon(Icons.Rounded.DeleteSweep, contentDescription = null) },
                onClick = onEmptyRecycleBin
            )
        }
        if (!isCoreSystem) {
            HorizontalDivider()
            DropdownMenuItem(
                text = { Text("Move to Recycle Bin", color = MaterialTheme.colorScheme.error) },
                leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
                onClick = onDelete
            )
        }
        HorizontalDivider()
        DropdownMenuItem(
            text = { Text("Properties") },
            leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
            onClick = onProperties
        )
    }
}

@Composable
private fun DesktopClockWidget(
    currentTimeMillis: Long,
    isLandscapeOrWide: Boolean,
    modifier: Modifier = Modifier
) {
    val date = remember(currentTimeMillis) { Date(currentTimeMillis) }
    val timeStr = remember(currentTimeMillis) {
        SimpleDateFormat("HH:mm", Locale.getDefault()).format(date)
    }
    val dateStr = remember(currentTimeMillis) {
        SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(date)
    }

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0x450F172A),
        modifier = modifier.border(1.dp, Color(0x28FFFFFF), RoundedCornerShape(16.dp))
    ) {
        Column(
            horizontalAlignment = Alignment.End,
            modifier = Modifier.padding(horizontal = if (isLandscapeOrWide) 18.dp else 14.dp, vertical = 10.dp)
        ) {
            Text(
                text = timeStr,
                color = Color.White,
                fontSize = if (isLandscapeOrWide) 34.sp else 26.sp,
                fontWeight = FontWeight.SemiBold,
                fontFamily = JetBrainsMonoFamily
            )
            Text(
                text = dateStr,
                color = Color.White.copy(alpha = 0.85f),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
fun TextInputDialog(
    title: String,
    label: String,
    initialValue: String,
    confirmLabel: String,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var text by remember(initialValue) { mutableStateOf(initialValue) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(label) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(text) },
                enabled = text.isNotBlank()
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
