package com.example.ui.windows

import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.DesktopWindows
import androidx.compose.material.icons.rounded.Dock
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AnimationSpeed
import com.example.data.model.IconSizeOption
import com.example.data.model.InstalledApp
import com.example.data.model.PcSettingsState
import com.example.data.model.SystemStatus
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.ThemeMode
import com.example.data.model.WallpaperPreset
import com.example.ui.components.AppPackageIcon
import com.example.ui.components.formatBytes
import com.example.ui.theme.AccentPreset
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.theme.SuccessGreen
import com.example.ui.viewmodel.LauncherViewModel

private enum class SettingsTab(val label: String, val icon: ImageVector) {
    SYSTEM("System & Home", Icons.Rounded.Computer),
    PERSONALIZATION("Wallpaper & Theme", Icons.Rounded.Palette),
    DESKTOP("Desktop & Icons", Icons.Rounded.DesktopWindows),
    TASKBAR("Taskbar", Icons.Rounded.Dock),
    ANIMATIONS("Animations", Icons.Rounded.Animation),
    DEFAULT_APPS("Default Shortcuts", Icons.Rounded.Apps)
}

@Composable
fun PcSettingsWindow(
    settings: PcSettingsState,
    systemStatus: SystemStatus,
    installedApps: List<InstalledApp>,
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    var activeTab by remember { mutableStateOf(SettingsTab.SYSTEM) }
    var appPickerSlot by remember { mutableStateOf<Pair<String, String>?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.setCustomWallpaperUri(uri.toString())
            viewModel.showMessage("Custom desktop wallpaper applied")
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val wideLayout = maxWidth >= 520.dp

        Column(modifier = Modifier.fillMaxSize()) {
            if (!wideLayout) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 8.dp)
                ) {
                    SettingsTab.entries.forEach { tab ->
                        FilterChip(
                            selected = activeTab == tab,
                            onClick = { activeTab = tab },
                            label = { Text(tab.label) },
                            leadingIcon = { Icon(tab.icon, contentDescription = null, modifier = Modifier.size(16.dp)) }
                        )
                    }
                }
                HorizontalDivider(color = pcPalette.windowBorder)
            }

            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (wideLayout) {
                    LazyColumn(
                        contentPadding = PaddingValues(10.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .width(195.dp)
                            .fillMaxHeight()
                            .background(pcPalette.windowHeader.copy(alpha = 0.35f))
                    ) {
                        items(SettingsTab.entries) { tab ->
                            val selected = activeTab == tab
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (selected) pcPalette.accent.copy(alpha = 0.18f) else Color.Transparent)
                                    .clickable { activeTab = tab }
                                    .padding(horizontal = 10.dp, vertical = 10.dp)
                            ) {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.label,
                                    tint = if (selected) pcPalette.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    text = tab.label,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
                                )
                            }
                        }
                    }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(pcPalette.windowBorder))
                }

                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f).fillMaxHeight()
                ) {
                    when (activeTab) {
                        SettingsTab.SYSTEM -> {
                            item {
                                Text("Default Android Home Launcher", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                SettingsCard {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = if (systemStatus.isDefaultLauncher) Icons.Rounded.CheckCircle else Icons.Rounded.Home,
                                            contentDescription = null,
                                            tint = if (systemStatus.isDefaultLauncher) SuccessGreen else pcPalette.accent,
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(Modifier.width(12.dp))
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = if (systemStatus.isDefaultLauncher) {
                                                    "PC Desktop Launcher is your Default Home App"
                                                } else {
                                                    "Not yet set as Default Home App"
                                                },
                                                style = MaterialTheme.typography.titleSmall
                                            )
                                            Text(
                                                text = "Registered with Android HOME & DEFAULT intent filters.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Button(
                                            onClick = onRequestDefaultHome,
                                            modifier = Modifier.testTag("settings_set_default_home")
                                        ) {
                                            Text(if (systemStatus.isDefaultLauncher) "Change Home App" else "Set as Default Home")
                                        }
                                        OutlinedButton(onClick = { viewModel.openAndroidSystemSettings(Settings.ACTION_DISPLAY_SETTINGS) }) {
                                            Text("Android Display")
                                        }
                                    }
                                }
                            }

                            item {
                                Text("Window Management & Android Support", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                SettingsCard {
                                    Text(
                                        text = "Built-in launcher windows (File Explorer, PC Settings, Recycle Bin, Notepad, Task Manager, Folders) run inside draggable, resizable desktop panels. Third-party Android apps open via Android's Activity manager; Android does not allow standard launchers to embed arbitrary third-party apps inside custom launcher views without system/root privileges.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Spacer(Modifier.height(10.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text("Request Freeform Bounds on Launch", style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = if (systemStatus.supportsFreeformWindows) {
                                                    "Device advertises Android freeform window management."
                                                } else {
                                                    "Standard Android full-screen activity launch on this device."
                                                },
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Switch(
                                            checked = settings.preferFreeformLaunch,
                                            onCheckedChange = { viewModel.setPreferFreeformLaunch(it) }
                                        )
                                    }
                                }
                            }

                            item {
                                Text("Device Specifications", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                SettingsCard {
                                    SpecRow("Device Model", "${Build.MANUFACTURER} ${Build.MODEL}")
                                    SpecRow("Android Version", "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
                                    SpecRow("Total RAM", formatBytes(systemStatus.ramTotalBytes))
                                    SpecRow("Internal Storage", formatBytes(systemStatus.storageTotalBytes))
                                }
                            }
                        }

                        SettingsTab.PERSONALIZATION -> {
                            item {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Desktop Wallpaper", style = MaterialTheme.typography.titleMedium)
                                    OutlinedButton(
                                        onClick = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        }
                                    ) {
                                        Icon(Icons.Rounded.Image, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text("Pick Photo")
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    WallpaperPreset.entries.chunked(2).forEach { pair ->
                                        Row(
                                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                                            modifier = Modifier.fillMaxWidth()
                                        ) {
                                            pair.forEach { preset ->
                                                val selected = settings.customWallpaperUri == null && settings.wallpaperId == preset.id
                                                WallpaperTile(
                                                    preset = preset,
                                                    selected = selected,
                                                    onClick = { viewModel.updateWallpaperPreset(preset.id) },
                                                    modifier = Modifier.weight(1f)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                Text("Theme Mode", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    ThemeMode.entries.forEach { mode ->
                                        FilterChip(
                                            selected = settings.themeMode == mode,
                                            onClick = { viewModel.updateThemeMode(mode) },
                                            label = { Text(mode.label) },
                                            modifier = Modifier.testTag("theme_mode_${mode.name}")
                                        )
                                    }
                                }
                            }

                            item {
                                Text("Accent Color", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    AccentPreset.entries.forEach { preset ->
                                        val selected = settings.accentKey == preset.key
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(if (pcPalette.isDark) preset.dark else preset.light)
                                                .then(
                                                    if (selected) Modifier.border(3.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                                    else Modifier
                                                )
                                                .clickable { viewModel.updateAccentKey(preset.key) }
                                        )
                                    }
                                }
                            }
                        }

                        SettingsTab.DESKTOP -> {
                            item {
                                Text("Desktop Icon Size", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconSizeOption.entries.forEach { opt ->
                                        FilterChip(
                                            selected = settings.iconSize == opt,
                                            onClick = { viewModel.updateIconSize(opt) },
                                            label = { Text(opt.label) }
                                        )
                                    }
                                }
                            }

                            item {
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Auto-Arrange Desktop Grid",
                                        subtitle = "Keep desktop icons aligned neatly in columns.",
                                        checked = settings.autoArrangeGrid,
                                        onCheckedChange = { viewModel.setAutoArrangeGrid(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Desktop Clock Widget",
                                        subtitle = "Show floating time and date widget on desktop.",
                                        checked = settings.showDesktopClock,
                                        onCheckedChange = { viewModel.setShowDesktopClock(it) }
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Show File Name Extensions",
                                        subtitle = "Display .txt, .md, and file suffixes on desktop shortcuts.",
                                        checked = settings.showFileExtensions,
                                        onCheckedChange = { viewModel.setShowFileExtensions(it) }
                                    )
                                }
                            }

                            item {
                                OutlinedButton(onClick = { viewModel.resetDefaultDesktopIcons() }) {
                                    Text("Restore Default Desktop Shortcuts")
                                }
                            }
                        }

                        SettingsTab.TASKBAR -> {
                            item {
                                Text("Taskbar Position", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TaskbarPosition.entries.forEach { pos ->
                                        FilterChip(
                                            selected = settings.taskbarPosition == pos,
                                            onClick = { viewModel.updateTaskbarPosition(pos) },
                                            label = { Text(pos.label) }
                                        )
                                    }
                                }
                            }

                            item {
                                Text("Taskbar Size", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    TaskbarSizeOption.entries.forEach { opt ->
                                        FilterChip(
                                            selected = settings.taskbarSize == opt,
                                            onClick = { viewModel.updateTaskbarSize(opt) },
                                            label = { Text(opt.label) }
                                        )
                                    }
                                }
                            }

                            item {
                                SettingsCard {
                                    Text("Taskbar Transparency (${(settings.taskbarTransparency * 100).toInt()}%)", style = MaterialTheme.typography.bodyMedium)
                                    Slider(
                                        value = settings.taskbarTransparency,
                                        onValueChange = { viewModel.updateTaskbarTransparency(it) },
                                        valueRange = 0.35f..0.98f
                                    )
                                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = pcPalette.windowBorder)
                                    ToggleSettingRow(
                                        title = "Show Search Button in Taskbar",
                                        subtitle = "Quickly open Start Menu search from the taskbar.",
                                        checked = settings.showTaskbarSearch,
                                        onCheckedChange = { viewModel.setShowTaskbarSearch(it) }
                                    )
                                }
                            }
                        }

                        SettingsTab.ANIMATIONS -> {
                            item {
                                SettingsCard {
                                    ToggleSettingRow(
                                        title = "Desktop & Menu Animations",
                                        subtitle = "Smooth transitions for Start Menu, Flyouts, and Windows.",
                                        checked = settings.animationsEnabled,
                                        onCheckedChange = { viewModel.setAnimationsEnabled(it) }
                                    )
                                }
                            }

                            item {
                                Text("Animation Speed", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    AnimationSpeed.entries.forEach { spd ->
                                        FilterChip(
                                            selected = settings.animationSpeed == spd,
                                            onClick = { viewModel.updateAnimationSpeed(spd) },
                                            label = { Text(spd.label) },
                                            enabled = settings.animationsEnabled
                                        )
                                    }
                                }
                            }
                        }

                        SettingsTab.DEFAULT_APPS -> {
                            item {
                                Text("Default App Shortcuts", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    "Choose preferred Android apps for quick launching from your PC desktop.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(Modifier.height(8.dp))
                                val slots = listOf(
                                    Triple("browser", "Web Browser", settings.defaultBrowserPackage),
                                    Triple("files", "External Files App", settings.defaultFilesPackage),
                                    Triple("gallery", "Photos / Gallery", settings.defaultGalleryPackage),
                                    Triple("music", "Music Player", settings.defaultMusicPackage)
                                )
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    slots.forEach { (slotKey, slotTitle, currentPkg) ->
                                        val matched = installedApps.firstOrNull { it.packageName == currentPkg }
                                        SettingsCard {
                                            Row(
                                                verticalAlignment = Alignment.CenterVertically,
                                                modifier = Modifier.fillMaxWidth()
                                            ) {
                                                if (matched != null) {
                                                    AppPackageIcon(
                                                        packageName = matched.packageName,
                                                        activityName = matched.activityName,
                                                        contentDescription = matched.label,
                                                        viewModel = viewModel,
                                                        size = 32.dp
                                                    )
                                                    Spacer(Modifier.width(10.dp))
                                                }
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(slotTitle, style = MaterialTheme.typography.titleSmall)
                                                    Text(
                                                        text = matched?.label ?: "Not assigned",
                                                        style = MaterialTheme.typography.bodySmall,
                                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                                    )
                                                }
                                                OutlinedButton(onClick = { appPickerSlot = slotKey to slotTitle }) {
                                                    Text("Choose")
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    appPickerSlot?.let { (slotKey, slotTitle) ->
        AlertDialog(
            onDismissRequest = { appPickerSlot = null },
            title = { Text("Choose $slotTitle") },
            text = {
                LazyColumn(modifier = Modifier.height(320.dp)) {
                    item {
                        TextButton(
                            onClick = {
                                viewModel.setDefaultShortcut(slotKey, null)
                                appPickerSlot = null
                            }
                        ) {
                            Text("Clear Assignment")
                        }
                    }
                    items(installedApps, key = { it.componentKey }) { app ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    viewModel.setDefaultShortcut(slotKey, app.packageName)
                                    appPickerSlot = null
                                }
                                .padding(vertical = 8.dp, horizontal = 6.dp)
                        ) {
                            AppPackageIcon(
                                packageName = app.packageName,
                                activityName = app.activityName,
                                contentDescription = app.label,
                                viewModel = viewModel,
                                size = 28.dp
                            )
                            Spacer(Modifier.width(10.dp))
                            Text(app.label, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { appPickerSlot = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    val pcPalette = LocalPcPalette.current
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = pcPalette.windowCard,
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            content()
        }
    }
}

@Composable
private fun SpecRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
    ) {
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodySmall, fontFamily = JetBrainsMonoFamily)
    }
}

@Composable
private fun ToggleSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun WallpaperTile(
    preset: WallpaperPreset,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) pcPalette.accent else pcPalette.windowBorder,
                shape = RoundedCornerShape(10.dp)
            )
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(74.dp)
        ) {
            when (preset) {
                WallpaperPreset.BLOOM -> Image(
                    painter = painterResource(R.drawable.img_wallpaper_bloom),
                    contentDescription = preset.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.SUNRISE -> Image(
                    painter = painterResource(R.drawable.img_wallpaper_sunrise),
                    contentDescription = preset.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.AURORA -> Image(
                    painter = painterResource(R.drawable.img_wallpaper_aurora),
                    contentDescription = preset.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.SUNSET -> Image(
                    painter = painterResource(R.drawable.img_wallpaper_sunset),
                    contentDescription = preset.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                WallpaperPreset.MIDNIGHT_MESH -> Box(
                    Modifier.fillMaxSize().background(Brush.radialGradient(listOf(Color(0xFF1E293B), Color(0xFF050811))))
                )
                WallpaperPreset.OCEAN_GLASS -> Box(
                    Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Color(0xFF0B3B6F), Color(0xFF0F172A))))
                )
            }
        }
        Text(
            text = preset.title,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            modifier = Modifier.padding(8.dp)
        )
    }
}
