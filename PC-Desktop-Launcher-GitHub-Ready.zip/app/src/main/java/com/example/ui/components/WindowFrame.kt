package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CropSquare
import androidx.compose.material.icons.rounded.DragIndicator
import androidx.compose.material.icons.rounded.FilterNone
import androidx.compose.material.icons.rounded.Minimize
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.example.data.model.DesktopWindow
import com.example.ui.theme.LocalPcPalette

@Composable
fun WindowFrame(
    window: DesktopWindow,
    isActive: Boolean,
    onFocus: () -> Unit,
    onMinimize: () -> Unit,
    onToggleMaximize: () -> Unit,
    onClose: () -> Unit,
    onMove: (dxDp: Float, dyDp: Float) -> Unit,
    onResize: (dwDp: Float, dhDp: Float) -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    val density = LocalDensity.current

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val containerW = maxWidth.value
        val containerH = maxHeight.value
        val isCompactScreen = containerW < 520f

        val effectiveMaximized = window.isMaximized || (isCompactScreen && !window.isMinimized && window.widthDp >= containerW - 12f)
        val clampedWidth = if (effectiveMaximized) containerW else window.widthDp.coerceIn(290f, (containerW - 8f).coerceAtLeast(290f))
        val clampedHeight = if (effectiveMaximized) containerH else window.heightDp.coerceIn(240f, (containerH - 8f).coerceAtLeast(240f))
        val clampedX = if (effectiveMaximized) 0f else window.xOffsetDp.coerceIn(0f, (containerW - clampedWidth).coerceAtLeast(0f))
        val clampedY = if (effectiveMaximized) 0f else window.yOffsetDp.coerceIn(0f, (containerH - clampedHeight).coerceAtLeast(0f))

        val cornerShape = if (effectiveMaximized) RoundedCornerShape(0.dp) else RoundedCornerShape(14.dp)

        Surface(
            shape = cornerShape,
            color = pcPalette.windowSurface,
            tonalElevation = if (isActive) 12.dp else 4.dp,
            shadowElevation = if (isActive) 18.dp else 6.dp,
            modifier = Modifier
                .zIndex(window.zIndex.toFloat())
                .offset(x = clampedX.dp, y = clampedY.dp)
                .size(width = clampedWidth.dp, height = clampedHeight.dp)
                .border(
                    width = if (isActive) 1.2.dp else 0.8.dp,
                    color = if (isActive) pcPalette.accent.copy(alpha = 0.55f) else pcPalette.windowBorder,
                    shape = cornerShape
                )
                .pointerInput(window.id) {
                    detectTapGestures(onPress = { onFocus() })
                }
                .testTag("window_${window.type.name}")
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Windows 11 Title Bar
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .background(pcPalette.windowHeader)
                            .pointerInput(window.id, effectiveMaximized) {
                                if (!effectiveMaximized) {
                                    detectDragGestures(
                                        onDragStart = { onFocus() },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            with(density) {
                                                onMove(dragAmount.x.toDp().value, dragAmount.y.toDp().value)
                                            }
                                        }
                                    )
                                }
                            }
                            .padding(start = 12.dp, end = 4.dp)
                    ) {
                        Icon(
                            imageVector = windowTypeIcon(window.type),
                            contentDescription = null,
                            tint = windowTypeTint(window.type, pcPalette.accent),
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = window.title,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                            IconButton(
                                onClick = onMinimize,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("window_minimize_${window.type.name}")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Minimize,
                                    contentDescription = "Minimize",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            IconButton(
                                onClick = onToggleMaximize,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("window_maximize_${window.type.name}")
                            ) {
                                Icon(
                                    imageVector = if (window.isMaximized) Icons.Rounded.FilterNone else Icons.Rounded.CropSquare,
                                    contentDescription = if (window.isMaximized) "Restore" else "Maximize",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            IconButton(
                                onClick = onClose,
                                modifier = Modifier
                                    .size(48.dp)
                                    .testTag("window_close_${window.type.name}")
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Close,
                                    contentDescription = "Close",
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = pcPalette.windowBorder)

                    // Window Body
                    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                        content()
                    }
                }

                // Bottom-Right Resize Grip (only when floating)
                if (!effectiveMaximized && !isCompactScreen) {
                    Box(
                        contentAlignment = Alignment.BottomEnd,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .size(26.dp)
                            .clip(RoundedCornerShape(topStart = 8.dp))
                            .pointerInput(window.id) {
                                detectDragGestures(
                                    onDragStart = { onFocus() },
                                    onDrag = { change, dragAmount ->
                                        change.consume()
                                        with(density) {
                                            onResize(dragAmount.x.toDp().value, dragAmount.y.toDp().value)
                                        }
                                    }
                                )
                            }
                            .padding(3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.DragIndicator,
                            contentDescription = "Resize Window",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
