package com.example.ui.components

import android.provider.Settings
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ExitToApp
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.AddToHomeScreen
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.DisplaySettings
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PowerSettingsNew
import androidx.compose.material.icons.rounded.PushPin
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.local.PinnedAppEntity
import com.example.data.model.InstalledApp
import com.example.data.model.WindowType
import com.example.ui.theme.FolderAmber
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.LauncherViewModel

private data class BuiltInPcTool(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tint: Color,
    val onOpen: () -> Unit
)

@Composable
fun WindowsStartMenu(
    installedApps: List<InstalledApp>,
    pinnedApps: List<PinnedAppEntity>,
    recentApps: List<InstalledApp>,
    focusSearchOnOpen: Boolean,
    powerMenuOpen: Boolean,
    viewModel: LauncherViewModel,
    onRequestDefaultHome: () -> Unit,
    onExitLauncher: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var showAllApps by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(focusSearchOnOpen) {
        if (focusSearchOnOpen) {
            runCatching { focusRequester.requestFocus() }
        }
    }

    val builtInTools = remember(viewModel) {
        listOf(
            BuiltInPcTool("File Explorer", "Browse storage & SAF drives", Icons.Rounded.Folder, FolderAmber) {
                viewModel.openWindow(WindowType.FILE_EXPLORER, "This PC")
            },
            BuiltInPcTool("PC Settings", "Theme, wallpaper & Home setup", Icons.Rounded.Settings, Color(0xFF60A5FA)) {
                viewModel.openWindow(WindowType.PC_SETTINGS, "PC Settings")
            },
            BuiltInPcTool("Recycle Bin", "Deleted shortcuts & restore", Icons.Rounded.DeleteOutline, Color(0xFF38BDF8)) {
                viewModel.openWindow(WindowType.RECYCLE_BIN, "Recycle Bin")
            },
            BuiltInPcTool("Task Manager", "RAM, battery & active windows", Icons.Rounded.MonitorHeart, Color(0xFF10B981)) {
                viewModel.openWindow(WindowType.TASK_MONITOR, "Task Manager")
            }
        )
    }

    val startPinnedKeys = remember(pinnedApps) {
        pinnedApps.filter { it.pinnedToStart }.map { it.componentKey }.toSet()
    }
    val pinnedInstalledApps = remember(installedApps, startPinnedKeys) {
        val matched = installedApps.filter { it.componentKey in startPinnedKeys }
        if (matched.isNotEmpty()) matched else installedApps.take(8)
    }

    val filteredApps = remember(installedApps, searchQuery) {
        if (searchQuery.isBlank()) installedApps
        else installedApps.filter {
            it.label.contains(searchQuery, ignoreCase = true) ||
                it.packageName.contains(searchQuery, ignoreCase = true)
        }
    }
    val filteredTools = remember(builtInTools, searchQuery) {
        if (searchQuery.isBlank()) emptyList()
        else builtInTools.filter { it.title.contains(searchQuery, ignoreCase = true) }
    }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = pcPalette.flyoutSurface,
        tonalElevation = 14.dp,
        shadowElevation = 20.dp,
        modifier = modifier
            .widthIn(min = 310.dp, max = 560.dp)
            .heightIn(min = 360.dp, max = 560.dp)
            .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(18.dp))
            .testTag("start_menu_panel")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Type to search apps and PC tools") },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Rounded.Clear, contentDescription = "Clear search")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .focusRequester(focusRequester)
                    .testTag("start_search_input")
            )

            // Body Content
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (searchQuery.isNotBlank() || showAllApps) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 18.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = if (searchQuery.isNotBlank()) "Search Results" else "All Apps (${installedApps.size})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            if (searchQuery.isBlank()) {
                                TextButton(onClick = { showAllApps = false }) {
                                    Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Back")
                                }
                            }
                        }

                        LazyColumn(
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredTools, key = { "tool_${it.title}" }) { tool ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { tool.onOpen() }
                                        .padding(horizontal = 10.dp, vertical = 8.dp)
                                ) {
                                    Icon(tool.icon, contentDescription = tool.title, tint = tool.tint, modifier = Modifier.size(28.dp))
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(tool.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                        Text(tool.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }

                            items(filteredApps, key = { it.componentKey }) { app ->
                                AppListRow(
                                    app = app,
                                    isPinnedStart = app.componentKey in startPinnedKeys,
                                    isPinnedTaskbar = pinnedApps.any { it.componentKey == app.componentKey && it.pinnedToTaskbar },
                                    viewModel = viewModel
                                )
                            }

                            if (filteredApps.isEmpty() && filteredTools.isEmpty()) {
                                item {
                                    Text(
                                        text = "No matching apps found",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(18.dp)
                                    )
                                }
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 16.dp)
                    ) {
                        // Pinned Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Pinned", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                            TextButton(
                                onClick = { showAllApps = true },
                                modifier = Modifier.testTag("start_all_apps_button")
                            ) {
                                Text("All Apps")
                                Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, contentDescription = null, modifier = Modifier.size(18.dp))
                            }
                        }

                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 78.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(builtInTools, key = { "pinned_tool_${it.title}" }) { tool ->
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { tool.onOpen() }
                                        .padding(vertical = 8.dp, horizontal = 4.dp)
                                ) {
                                    Icon(tool.icon, contentDescription = tool.title, tint = tool.tint, modifier = Modifier.size(34.dp))
                                    Spacer(Modifier.height(6.dp))
                                    Text(
                                        text = tool.title,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }

                            items(pinnedInstalledApps, key = { it.componentKey }) { app ->
                                PinnedAppTile(
                                    app = app,
                                    isPinnedTaskbar = pinnedApps.any { it.componentKey == app.componentKey && it.pinnedToTaskbar },
                                    viewModel = viewModel
                                )
                            }
                        }

                        // Recently Used Apps
                        if (recentApps.isNotEmpty()) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = "Recommended / Recent",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(Modifier.height(6.dp))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(bottom = 10.dp)
                            ) {
                                recentApps.take(4).forEach { app ->
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier
                                            .weight(1f)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(pcPalette.windowCard.copy(alpha = 0.65f))
                                            .clickable { viewModel.launchInstalledApp(app) }
                                            .padding(8.dp)
                                    ) {
                                        AppPackageIcon(
                                            packageName = app.packageName,
                                            activityName = app.activityName,
                                            contentDescription = app.label,
                                            viewModel = viewModel,
                                            size = 24.dp
                                        )
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            text = app.label,
                                            style = MaterialTheme.typography.labelSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Start Menu Footer (User & Power Options)
            HorizontalDivider(color = pcPalette.windowBorder)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(pcPalette.windowHeader.copy(alpha = 0.7f))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(pcPalette.accent.copy(alpha = 0.22f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Person,
                            contentDescription = null,
                            tint = pcPalette.accent,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(
                        text = android.os.Build.MODEL ?: "Android PC",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Medium
                    )
                }

                Box {
                    IconButton(
                        onClick = { viewModel.togglePowerMenu() },
                        modifier = Modifier.testTag("power_menu_button")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PowerSettingsNew,
                            contentDescription = "Power & Launcher Options"
                        )
                    }

                    DropdownMenu(
                        expanded = powerMenuOpen,
                        onDismissRequest = { viewModel.togglePowerMenu() }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Reload Desktop") },
                            leadingIcon = { Icon(Icons.Rounded.Refresh, contentDescription = null) },
                            onClick = {
                                viewModel.closeAllFlyouts()
                                viewModel.refreshDesktopAndApps()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Switch Home Launcher") },
                            leadingIcon = { Icon(Icons.Rounded.Home, contentDescription = null) },
                            onClick = {
                                viewModel.closeAllFlyouts()
                                onRequestDefaultHome()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Display & Screen Timeout") },
                            leadingIcon = { Icon(Icons.Rounded.DisplaySettings, contentDescription = null) },
                            onClick = {
                                viewModel.openAndroidSystemSettings(Settings.ACTION_DISPLAY_SETTINGS)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Android System Settings") },
                            leadingIcon = { Icon(Icons.Rounded.Computer, contentDescription = null) },
                            onClick = {
                                viewModel.openAndroidSystemSettings(Settings.ACTION_SETTINGS)
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Close Launcher Window") },
                            leadingIcon = { Icon(Icons.AutoMirrored.Rounded.ExitToApp, contentDescription = null) },
                            onClick = {
                                viewModel.closeAllFlyouts()
                                onExitLauncher()
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PinnedAppTile(
    app: InstalledApp,
    isPinnedTaskbar: Boolean,
    viewModel: LauncherViewModel
) {
    var showMenu by remember { mutableStateOf(false) }

    Box {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .combinedClickable(
                    onClick = { viewModel.launchInstalledApp(app) },
                    onLongClick = { showMenu = true }
                )
                .padding(vertical = 8.dp, horizontal = 4.dp)
        ) {
            AppPackageIcon(
                packageName = app.packageName,
                activityName = app.activityName,
                contentDescription = app.label,
                viewModel = viewModel,
                size = 34.dp
            )
            Spacer(Modifier.height(6.dp))
            Text(
                text = app.label,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }

        AppItemContextMenu(
            app = app,
            expanded = showMenu,
            isPinnedStart = true,
            isPinnedTaskbar = isPinnedTaskbar,
            onDismiss = { showMenu = false },
            viewModel = viewModel
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppListRow(
    app: InstalledApp,
    isPinnedStart: Boolean,
    isPinnedTaskbar: Boolean,
    viewModel: LauncherViewModel
) {
    var showMenu by remember { mutableStateOf(false) }

    Box {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .combinedClickable(
                    onClick = { viewModel.launchInstalledApp(app) },
                    onLongClick = { showMenu = true }
                )
                .padding(horizontal = 10.dp, vertical = 8.dp)
        ) {
            AppPackageIcon(
                packageName = app.packageName,
                activityName = app.activityName,
                contentDescription = app.label,
                viewModel = viewModel,
                size = 30.dp
            )
            Spacer(Modifier.width(12.dp))
            Text(
                text = app.label,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.weight(1f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            IconButton(onClick = { showMenu = true }) {
                Icon(Icons.Rounded.PushPin, contentDescription = "Pin options", modifier = Modifier.size(16.dp))
            }
        }

        AppItemContextMenu(
            app = app,
            expanded = showMenu,
            isPinnedStart = isPinnedStart,
            isPinnedTaskbar = isPinnedTaskbar,
            onDismiss = { showMenu = false },
            viewModel = viewModel
        )
    }
}

@Composable
private fun AppItemContextMenu(
    app: InstalledApp,
    expanded: Boolean,
    isPinnedStart: Boolean,
    isPinnedTaskbar: Boolean,
    onDismiss: () -> Unit,
    viewModel: LauncherViewModel
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Open ${app.label}") },
            onClick = {
                onDismiss()
                viewModel.launchInstalledApp(app)
            }
        )
        DropdownMenuItem(
            text = { Text(if (isPinnedStart) "Unpin from Start" else "Pin to Start") },
            leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
            onClick = {
                onDismiss()
                viewModel.togglePinToStart(app)
            }
        )
        DropdownMenuItem(
            text = { Text(if (isPinnedTaskbar) "Unpin from Taskbar" else "Pin to Taskbar") },
            leadingIcon = { Icon(Icons.Rounded.PushPin, contentDescription = null) },
            onClick = {
                onDismiss()
                viewModel.togglePinToTaskbar(app)
            }
        )
        DropdownMenuItem(
            text = { Text("Add to Desktop") },
            leadingIcon = { Icon(Icons.Rounded.AddToHomeScreen, contentDescription = null) },
            onClick = {
                onDismiss()
                viewModel.addAppToDesktop(app)
            }
        )
        DropdownMenuItem(
            text = { Text("App Info") },
            leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
            onClick = {
                onDismiss()
                viewModel.openAppInfo(app.packageName)
            }
        )
    }
}
