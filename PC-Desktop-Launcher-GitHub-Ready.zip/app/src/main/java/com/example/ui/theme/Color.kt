package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class AccentPreset(val key: String, val label: String, val light: Color, val dark: Color) {
    WINDOWS_BLUE("blue", "Windows Blue", Color(0xFF0067C0), Color(0xFF60CDFF)),
    CYAN("cyan", "Electric Cyan", Color(0xFF00838F), Color(0xFF4DD0E1)),
    VIOLET("violet", "Fluorescent Violet", Color(0xFF6D28D9), Color(0xFFC4B5FD)),
    EMERALD("emerald", "Emerald Mint", Color(0xFF047857), Color(0xFF6EE7B7)),
    AMBER("amber", "Warm Amber", Color(0xFFB45309), Color(0xFFFCD34D)),
    ROSE("rose", "Coral Rose", Color(0xFFBE123C), Color(0xFFFDA4AF));

    companion object {
        fun fromKey(key: String): AccentPreset = entries.firstOrNull { it.key == key } ?: WINDOWS_BLUE
    }
}

// Neutral Windows 11 Mica / Acrylic Tokens
val LightBackground = Color(0xFFF3F3F3)
val LightSurface = Color(0xFFFAFAFA)
val LightSurfaceVariant = Color(0xFFEAECEF)
val LightBorder = Color(0x24000000)
val LightTextPrimary = Color(0xFF1A1A1A)
val LightTextSecondary = Color(0xFF5D6168)

val DarkBackground = Color(0xFF1A1D24)
val DarkSurface = Color(0xFF20242C)
val DarkSurfaceVariant = Color(0xFF2B303A)
val DarkBorder = Color(0x28FFFFFF)
val DarkTextPrimary = Color(0xFFF5F7FA)
val DarkTextSecondary = Color(0xFFA7B0BE)

val TaskbarDarkBase = Color(0xFF11151E)
val TaskbarLightBase = Color(0xFFF2F5FA)

val FolderAmber = Color(0xFFF5B841)
val RecycleBlue = Color(0xFF38BDF8)
val DangerRed = Color(0xFFEF4444)
val SuccessGreen = Color(0xFF10B981)
