package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.AudioFile
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.MonitorHeart
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VideoFile
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.ui.theme.FolderAmber
import com.example.ui.theme.RecycleBlue
import com.example.ui.viewmodel.LauncherViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WindowsLogoIcon(
    size: Dp = 22.dp,
    tintTopLeft: Color = Color(0xFF4CC2FF),
    tintTopRight: Color = Color(0xFF31A9F8),
    tintBottomLeft: Color = Color(0xFF0078D4),
    tintBottomRight: Color = Color(0xFF005FB8)
) {
    val gap = (size.value * 0.08f).dp
    val paneRadius = (size.value * 0.1f).dp
    Column(
        modifier = Modifier.size(size),
        verticalArrangement = Arrangement.spacedBy(gap)
    ) {
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(gap)
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(topStart = paneRadius))
                    .background(tintTopLeft)
            )
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(topEnd = paneRadius))
                    .background(tintTopRight)
            )
        }
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.spacedBy(gap)
        ) {
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(bottomStart = paneRadius))
                    .background(tintBottomLeft)
            )
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(bottomEnd = paneRadius))
                    .background(tintBottomRight)
            )
        }
    }
}

@Composable
fun AppPackageIcon(
    packageName: String,
    activityName: String,
    contentDescription: String,
    viewModel: LauncherViewModel,
    size: Dp = 36.dp,
    modifier: Modifier = Modifier
) {
    val iconBitmap by produceState<ImageBitmap?>(initialValue = null, packageName, activityName) {
        value = viewModel.loadAppIcon(packageName, activityName)
    }

    if (iconBitmap != null) {
        Image(
            bitmap = iconBitmap!!,
            contentDescription = contentDescription,
            contentScale = ContentScale.Fit,
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(size * 0.22f))
        )
    } else {
        Box(
            modifier = modifier
                .size(size)
                .clip(RoundedCornerShape(size * 0.22f))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Apps,
                contentDescription = contentDescription,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(size * 0.6f)
            )
        }
    }
}

@Composable
fun DesktopItemIcon(
    item: DesktopItem,
    recycleBinCount: Int,
    viewModel: LauncherViewModel,
    size: Dp = 42.dp
) {
    when (item.type) {
        DesktopItemType.THIS_PC -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF38BDF8), Color(0xFF0284C7)))
                    )
                    .padding(size * 0.16f),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Computer,
                    contentDescription = item.title,
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        DesktopItemType.PC_SETTINGS -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF64748B), Color(0xFF334155)))
                    )
                    .padding(size * 0.16f),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = item.title,
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        DesktopItemType.RECYCLE_BIN -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF1E293B), Color(0xFF0F172A)))
                    )
                    .padding(size * 0.16f),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (recycleBinCount > 0) Icons.Rounded.Delete else Icons.Rounded.DeleteOutline,
                    contentDescription = item.title,
                    tint = RecycleBlue,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        DesktopItemType.TASK_MONITOR -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFF10B981), Color(0xFF047857)))
                    )
                    .padding(size * 0.16f),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.MonitorHeart,
                    contentDescription = item.title,
                    tint = Color.White,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        DesktopItemType.FOLDER -> {
            Icon(
                imageVector = Icons.Rounded.Folder,
                contentDescription = item.title,
                tint = FolderAmber,
                modifier = Modifier.size(size)
            )
        }
        DesktopItemType.FILE -> {
            Box(
                modifier = Modifier
                    .size(size)
                    .clip(RoundedCornerShape(10.dp))
                    .background(
                        Brush.linearGradient(listOf(Color(0xFFF8FAFC), Color(0xFFCBD5E1)))
                    )
                    .padding(size * 0.16f),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Description,
                    contentDescription = item.title,
                    tint = Color(0xFF1D4ED8),
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        DesktopItemType.APP_SHORTCUT -> {
            AppPackageIcon(
                packageName = item.targetPackage.orEmpty(),
                activityName = item.targetActivity.orEmpty(),
                contentDescription = item.title,
                viewModel = viewModel,
                size = size
            )
        }
    }
}

@Composable
fun FileTypeIcon(name: String, isDirectory: Boolean, mimeType: String, size: Dp = 28.dp) {
    when {
        isDirectory -> Icon(
            imageVector = Icons.Rounded.Folder,
            contentDescription = "Folder",
            tint = FolderAmber,
            modifier = Modifier.size(size)
        )
        mimeType.startsWith("image/") -> Icon(
            imageVector = Icons.Rounded.Image,
            contentDescription = name,
            tint = Color(0xFF38BDF8),
            modifier = Modifier.size(size)
        )
        mimeType.startsWith("audio/") -> Icon(
            imageVector = Icons.Rounded.AudioFile,
            contentDescription = name,
            tint = Color(0xFFA855F7),
            modifier = Modifier.size(size)
        )
        mimeType.startsWith("video/") -> Icon(
            imageVector = Icons.Rounded.VideoFile,
            contentDescription = name,
            tint = Color(0xFFF43F5E),
            modifier = Modifier.size(size)
        )
        mimeType.startsWith("text/") || name.endsWith(".md", true) || name.endsWith(".json", true) -> Icon(
            imageVector = Icons.Rounded.Description,
            contentDescription = name,
            tint = Color(0xFF60A5FA),
            modifier = Modifier.size(size)
        )
        else -> Icon(
            imageVector = Icons.Rounded.InsertDriveFile,
            contentDescription = name,
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(size)
        )
    }
}

fun formatBytes(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var idx = 0
    while (value >= 1024.0 && idx < units.lastIndex) {
        value /= 1024.0
        idx++
    }
    return if (idx == 0) "${value.toLong()} B" else String.format(Locale.US, "%.1f %s", value, units[idx])
}

fun formatTimestamp(millis: Long): String {
    if (millis <= 0L) return ""
    return SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()).format(Date(millis))
}
