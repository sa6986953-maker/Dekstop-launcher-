package com.example.ui.windows

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.automirrored.rounded.ViewList
import androidx.compose.material.icons.rounded.AddLink
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Computer
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.CreateNewFolder
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.DriveFileRenameOutline
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.NoteAdd
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.SdStorage
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Storage
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.data.model.ExplorerRootSection
import com.example.data.model.FileNode
import com.example.data.model.SafMount
import com.example.data.model.SystemStatus
import com.example.ui.components.FileTypeIcon
import com.example.ui.components.TextInputDialog
import com.example.ui.components.formatBytes
import com.example.ui.components.formatTimestamp
import com.example.ui.theme.FolderAmber
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.LocalPcPalette
import com.example.ui.viewmodel.ExplorerUiState
import com.example.ui.viewmodel.LauncherViewModel

@Composable
fun FileExplorerWindow(
    explorerState: ExplorerUiState,
    safMounts: List<SafMount>,
    systemStatus: SystemStatus,
    viewModel: LauncherViewModel
) {
    val pcPalette = LocalPcPalette.current
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<FileNode?>(null) }
    var propertiesTarget by remember { mutableStateOf<FileNode?>(null) }

    val safTreeLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            viewModel.mountSafTreeUri(uri)
        }
    }

    val filteredFiles = remember(explorerState.files, explorerState.searchQuery) {
        if (explorerState.searchQuery.isBlank()) explorerState.files
        else explorerState.files.filter {
            it.name.contains(explorerState.searchQuery, ignoreCase = true)
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val showSidebar = maxWidth >= 520.dp

        Column(modifier = Modifier.fillMaxSize()) {
            // Top Explorer Command Bar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .background(pcPalette.windowHeader.copy(alpha = 0.6f))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .horizontalScroll(rememberScrollState())
            ) {
                IconButton(
                    onClick = { viewModel.navigateExplorerUp() },
                    enabled = explorerState.breadcrumbs.size > 1
                ) {
                    Icon(Icons.Rounded.ArrowUpward, contentDescription = "Up one level")
                }
                IconButton(onClick = { viewModel.refreshExplorerCurrentDir() }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "Refresh")
                }

                Spacer(Modifier.width(4.dp))

                OutlinedButton(
                    onClick = { showNewFolderDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.CreateNewFolder, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New Folder", style = MaterialTheme.typography.labelMedium)
                }

                OutlinedButton(
                    onClick = { showNewFileDialog = true },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Rounded.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("New Note", style = MaterialTheme.typography.labelMedium)
                }

                Button(
                    onClick = { safTreeLauncher.launch(null) },
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("mount_saf_button")
                ) {
                    Icon(Icons.Rounded.AddLink, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Mount Folder (SAF)", style = MaterialTheme.typography.labelMedium)
                }

                if (explorerState.clipboard != null && explorerState.currentPathOrUri != null) {
                    OutlinedButton(
                        onClick = { viewModel.pasteExplorerClipboard() },
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Rounded.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Paste", style = MaterialTheme.typography.labelMedium)
                    }
                }

                IconButton(onClick = { viewModel.toggleExplorerViewMode() }) {
                    Icon(
                        imageVector = if (explorerState.isGridView) Icons.AutoMirrored.Rounded.ViewList else Icons.Rounded.GridView,
                        contentDescription = "Toggle View"
                    )
                }
            }

            // Address Bar & Search Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = pcPalette.windowCard,
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                        .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(8.dp))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxSize()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Computer,
                            contentDescription = null,
                            tint = pcPalette.accent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(6.dp))
                        explorerState.breadcrumbs.forEachIndexed { idx, (label, pathOrUri) ->
                            if (idx > 0) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                            Text(
                                text = label,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = if (idx == explorerState.breadcrumbs.lastIndex) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .clickable {
                                        when {
                                            pathOrUri == null -> viewModel.navigateExplorerToThisPc()
                                            pathOrUri.startsWith("content://") -> viewModel.navigateExplorerToSafUri(pathOrUri, label)
                                            else -> viewModel.navigateExplorerToLocalPath(pathOrUri, label)
                                        }
                                    }
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                if (explorerState.currentPathOrUri != null) {
                    OutlinedTextField(
                        value = explorerState.searchQuery,
                        onValueChange = { viewModel.setExplorerSearch(it) },
                        placeholder = { Text("Filter", style = MaterialTheme.typography.bodySmall) },
                        leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        singleLine = true,
                        modifier = Modifier.width(150.dp)
                    )
                }
            }

            // Compact horizontal quick-jump strip when sidebar is hidden
            if (!showSidebar) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    ExplorerRootSection.entries.forEach { section ->
                        val active = (section == ExplorerRootSection.THIS_PC && explorerState.currentPathOrUri == null) ||
                            (section != ExplorerRootSection.THIS_PC && explorerState.currentLocationLabel == section.label)
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (active) pcPalette.accent.copy(alpha = 0.22f) else pcPalette.windowCard,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { viewModel.navigateExplorerToSection(section) }
                        ) {
                            Text(
                                text = section.label,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) pcPalette.accent else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                    safMounts.forEach { mount ->
                        val active = explorerState.currentPathOrUri == mount.treeUri
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (active) pcPalette.accent.copy(alpha = 0.22f) else pcPalette.windowCard,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable { viewModel.navigateExplorerToSafUri(mount.treeUri, mount.displayName) }
                        ) {
                            Text(
                                text = mount.displayName,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (active) pcPalette.accent else MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            HorizontalDivider(color = pcPalette.windowBorder)

            // Main Split Body
            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (showSidebar) {
                    ExplorerSidebar(
                        currentPathOrUri = explorerState.currentPathOrUri,
                        currentLabel = explorerState.currentLocationLabel,
                        safMounts = safMounts,
                        onSelectSection = { viewModel.navigateExplorerToSection(it) },
                        onSelectSafMount = { viewModel.navigateExplorerToSafUri(it.treeUri, it.displayName) },
                        onUnmountSaf = { viewModel.unmountSafDrive(it) },
                        modifier = Modifier
                            .width(185.dp)
                            .fillMaxHeight()
                            .background(pcPalette.windowHeader.copy(alpha = 0.35f))
                    )
                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .fillMaxHeight()
                            .background(pcPalette.windowBorder)
                    )
                }

                // Content Pane
                Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                    when {
                        explorerState.isLoading -> {
                            CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
                        }
                        explorerState.currentPathOrUri == null -> {
                            ThisPcOverview(
                                systemStatus = systemStatus,
                                safMounts = safMounts,
                                onSelectSection = { viewModel.navigateExplorerToSection(it) },
                                onSelectSafMount = { viewModel.navigateExplorerToSafUri(it.treeUri, it.displayName) },
                                onUnmountSaf = { viewModel.unmountSafDrive(it) },
                                onMountNewSaf = { safTreeLauncher.launch(null) }
                            )
                        }
                        filteredFiles.isEmpty() -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.fillMaxSize().padding(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Rounded.Folder,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f),
                                    modifier = Modifier.size(52.dp)
                                )
                                Spacer(Modifier.height(8.dp))
                                Text("This folder is empty", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    "Create a new folder or note, or paste files here.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        explorerState.isGridView -> {
                            LazyVerticalGrid(
                                columns = GridCells.Adaptive(minSize = 110.dp),
                                contentPadding = PaddingValues(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredFiles, key = { it.id }) { node ->
                                    FileGridCard(
                                        node = node,
                                        onOpen = { viewModel.openFileNode(node) },
                                        onOpenWith = { viewModel.openFileNodeWithAndroidApp(node) },
                                        onCopy = { viewModel.setExplorerClipboard(node, isCut = false) },
                                        onCut = { viewModel.setExplorerClipboard(node, isCut = true) },
                                        onRename = { renameTarget = node },
                                        onDelete = { viewModel.deleteFileNode(node) },
                                        onProperties = { propertiesTarget = node }
                                    )
                                }
                            }
                        }
                        else -> {
                            LazyColumn(
                                contentPadding = PaddingValues(8.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp),
                                modifier = Modifier.fillMaxSize()
                            ) {
                                items(filteredFiles, key = { it.id }) { node ->
                                    FileListRow(
                                        node = node,
                                        onOpen = { viewModel.openFileNode(node) },
                                        onOpenWith = { viewModel.openFileNodeWithAndroidApp(node) },
                                        onCopy = { viewModel.setExplorerClipboard(node, isCut = false) },
                                        onCut = { viewModel.setExplorerClipboard(node, isCut = true) },
                                        onRename = { renameTarget = node },
                                        onDelete = { viewModel.deleteFileNode(node) },
                                        onProperties = { propertiesTarget = node }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        TextInputDialog(
            title = "Create Folder",
            label = "Folder name",
            initialValue = "New Folder",
            confirmLabel = "Create",
            onDismiss = { showNewFolderDialog = false },
            onConfirm = { name ->
                showNewFolderDialog = false
                viewModel.createFolderInExplorer(name)
            }
        )
    }

    if (showNewFileDialog) {
        TextInputDialog(
            title = "Create Text File",
            label = "File name",
            initialValue = "Note.txt",
            confirmLabel = "Create",
            onDismiss = { showNewFileDialog = false },
            onConfirm = { name ->
                showNewFileDialog = false
                viewModel.createTextFileInExplorer(name)
            }
        )
    }

    renameTarget?.let { target ->
        TextInputDialog(
            title = "Rename Item",
            label = "New name",
            initialValue = target.name,
            confirmLabel = "Rename",
            onDismiss = { renameTarget = null },
            onConfirm = { newName ->
                renameTarget = null
                viewModel.renameFileNode(target, newName)
            }
        )
    }

    propertiesTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { propertiesTarget = null },
            title = { Text(target.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Kind: ${if (target.isDirectory) "Folder" else target.mimeType}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = if (target.isDirectory) "Items: ${target.sizeBytes}" else "Size: ${formatBytes(target.sizeBytes)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Text("Modified: ${formatTimestamp(target.lastModified)}", style = MaterialTheme.typography.bodySmall)
                    Text(
                        text = if (target.isSafDocument) "Provider: Android Storage Access Framework" else "Provider: Local PC Workspace",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { propertiesTarget = null }) { Text("Close") }
            }
        )
    }
}

@Composable
private fun ExplorerSidebar(
    currentPathOrUri: String?,
    currentLabel: String,
    safMounts: List<SafMount>,
    onSelectSection: (ExplorerRootSection) -> Unit,
    onSelectSafMount: (SafMount) -> Unit,
    onUnmountSaf: (SafMount) -> Unit,
    modifier: Modifier = Modifier
) {
    val pcPalette = LocalPcPalette.current
    LazyColumn(
        contentPadding = PaddingValues(8.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        modifier = modifier
    ) {
        item {
            Text(
                text = "Quick Access",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
        items(ExplorerRootSection.entries) { section ->
            val selected = (section == ExplorerRootSection.THIS_PC && currentPathOrUri == null) ||
                (section != ExplorerRootSection.THIS_PC && currentLabel == section.label && currentPathOrUri != null && !currentPathOrUri.startsWith("content://"))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selected) pcPalette.accent.copy(alpha = 0.18f) else Color.Transparent)
                    .clickable { onSelectSection(section) }
                    .padding(horizontal = 10.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = sectionIcon(section),
                    contentDescription = section.label,
                    tint = if (selected) pcPalette.accent else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(10.dp))
                Text(
                    text = section.label,
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1
                )
            }
        }

        if (safMounts.isNotEmpty()) {
            item {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "Mounted Android Drives",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            items(safMounts, key = { it.id }) { mount ->
                val selected = currentPathOrUri == mount.treeUri
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) pcPalette.accent.copy(alpha = 0.18f) else Color.Transparent)
                        .clickable { onSelectSafMount(mount) }
                        .padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.SdStorage,
                        contentDescription = mount.displayName,
                        tint = pcPalette.accent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = mount.displayName,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { onUnmountSaf(mount) }, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Rounded.Close, contentDescription = "Disconnect", modifier = Modifier.size(14.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ThisPcOverview(
    systemStatus: SystemStatus,
    safMounts: List<SafMount>,
    onSelectSection: (ExplorerRootSection) -> Unit,
    onSelectSafMount: (SafMount) -> Unit,
    onUnmountSaf: (SafMount) -> Unit,
    onMountNewSaf: () -> Unit
) {
    val pcPalette = LocalPcPalette.current
    val usedFrac = if (systemStatus.storageTotalBytes > 0L) {
        (systemStatus.storageUsedBytes.toFloat() / systemStatus.storageTotalBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Text("Drives & Storage", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = pcPalette.windowCard,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(12.dp))
                    .clickable { onSelectSection(ExplorerRootSection.DOCUMENTS) }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Rounded.Storage,
                        contentDescription = null,
                        tint = pcPalette.accent,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Internal Storage (Local Workspace C:)", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        LinearProgressIndicator(
                            progress = { usedFrac },
                            modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(Modifier.height(4.dp))
                        val free = (systemStatus.storageTotalBytes - systemStatus.storageUsedBytes).coerceAtLeast(0L)
                        Text(
                            text = "${formatBytes(free)} free of ${formatBytes(systemStatus.storageTotalBytes)}",
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = JetBrainsMonoFamily,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item {
            Text("User Libraries", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            val folders = ExplorerRootSection.entries.filter { it != ExplorerRootSection.THIS_PC }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                folders.chunked(2).forEach { pair ->
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        pair.forEach { sec ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = pcPalette.windowCard,
                                modifier = Modifier
                                    .weight(1f)
                                    .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(10.dp))
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onSelectSection(sec) }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(12.dp)
                                ) {
                                    Icon(
                                        imageVector = sectionIcon(sec),
                                        contentDescription = sec.label,
                                        tint = FolderAmber,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(Modifier.width(10.dp))
                                    Text(sec.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }

        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Android Storage Access (SAF)", style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = onMountNewSaf) {
                    Icon(Icons.Rounded.AddLink, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Connect Folder")
                }
            }
            if (safMounts.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = pcPalette.windowCard,
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(12.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            "Browse your real Android Downloads, Documents, Pictures, Music, or SD Card securely using Storage Access Framework.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = onMountNewSaf) {
                            Text("Mount Android Folder")
                        }
                    }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    safMounts.forEach { mount ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = pcPalette.windowCard,
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, pcPalette.windowBorder, RoundedCornerShape(10.dp))
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSelectSafMount(mount) }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(12.dp)
                            ) {
                                Icon(Icons.Rounded.SdStorage, contentDescription = null, tint = pcPalette.accent, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mount.displayName, style = MaterialTheme.typography.titleSmall)
                                    Text("Mounted SAF Volume", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                IconButton(onClick = { onUnmountSaf(mount) }) {
                                    Icon(Icons.Rounded.Close, contentDescription = "Disconnect")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileListRow(
    node: FileNode,
    onOpen: () -> Unit,
    onOpenWith: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onProperties: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val pcPalette = LocalPcPalette.current

    Box {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(pcPalette.windowCard.copy(alpha = 0.5f))
                .combinedClickable(
                    onClick = onOpen,
                    onLongClick = { showMenu = true }
                )
                .padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            FileTypeIcon(node.name, node.isDirectory, node.mimeType, size = 26.dp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = node.name,
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = if (node.isDirectory) "Folder" else formatBytes(node.sizeBytes),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontFamily = JetBrainsMonoFamily
                )
            }
            Text(
                text = formatTimestamp(node.lastModified),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        FileNodeContextMenu(
            node = node,
            expanded = showMenu,
            onDismiss = { showMenu = false },
            onOpen = onOpen,
            onOpenWith = onOpenWith,
            onCopy = onCopy,
            onCut = onCut,
            onRename = onRename,
            onDelete = onDelete,
            onProperties = onProperties
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileGridCard(
    node: FileNode,
    onOpen: () -> Unit,
    onOpenWith: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onProperties: () -> Unit
) {
    var showMenu by remember { mutableStateOf(false) }
    val pcPalette = LocalPcPalette.current

    Box {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(pcPalette.windowCard.copy(alpha = 0.6f))
                .combinedClickable(
                    onClick = onOpen,
                    onLongClick = { showMenu = true }
                )
                .padding(12.dp)
        ) {
            FileTypeIcon(node.name, node.isDirectory, node.mimeType, size = 36.dp)
            Spacer(Modifier.height(6.dp))
            Text(
                text = node.name,
                style = MaterialTheme.typography.labelMedium,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }

        FileNodeContextMenu(
            node = node,
            expanded = showMenu,
            onDismiss = { showMenu = false },
            onOpen = onOpen,
            onOpenWith = onOpenWith,
            onCopy = onCopy,
            onCut = onCut,
            onRename = onRename,
            onDelete = onDelete,
            onProperties = onProperties
        )
    }
}

@Composable
private fun FileNodeContextMenu(
    node: FileNode,
    expanded: Boolean,
    onDismiss: () -> Unit,
    onOpen: () -> Unit,
    onOpenWith: () -> Unit,
    onCopy: () -> Unit,
    onCut: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    onProperties: () -> Unit
) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(
            text = { Text("Open", fontWeight = FontWeight.SemiBold) },
            onClick = { onDismiss(); onOpen() }
        )
        if (!node.isDirectory) {
            DropdownMenuItem(
                text = { Text("Open with Android App") },
                leadingIcon = { Icon(Icons.AutoMirrored.Rounded.OpenInNew, contentDescription = null) },
                onClick = { onDismiss(); onOpenWith() }
            )
            DropdownMenuItem(
                text = { Text("Copy") },
                leadingIcon = { Icon(Icons.Rounded.ContentCopy, contentDescription = null) },
                onClick = { onDismiss(); onCopy() }
            )
            DropdownMenuItem(
                text = { Text("Cut (Move)") },
                leadingIcon = { Icon(Icons.Rounded.ContentCut, contentDescription = null) },
                onClick = { onDismiss(); onCut() }
            )
        }
        DropdownMenuItem(
            text = { Text("Rename") },
            leadingIcon = { Icon(Icons.Rounded.DriveFileRenameOutline, contentDescription = null) },
            onClick = { onDismiss(); onRename() }
        )
        DropdownMenuItem(
            text = { Text("Delete", color = MaterialTheme.colorScheme.error) },
            leadingIcon = { Icon(Icons.Rounded.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            onClick = { onDismiss(); onDelete() }
        )
        HorizontalDivider()
        DropdownMenuItem(
            text = { Text("Properties") },
            leadingIcon = { Icon(Icons.Rounded.Info, contentDescription = null) },
            onClick = { onDismiss(); onProperties() }
        )
    }
}

private fun sectionIcon(section: ExplorerRootSection): ImageVector = when (section) {
    ExplorerRootSection.THIS_PC -> Icons.Rounded.Computer
    ExplorerRootSection.DESKTOP -> Icons.Rounded.Folder
    ExplorerRootSection.DOCUMENTS -> Icons.Rounded.Description
    ExplorerRootSection.DOWNLOADS -> Icons.Rounded.Download
    ExplorerRootSection.PICTURES -> Icons.Rounded.Image
    ExplorerRootSection.MUSIC -> Icons.Rounded.LibraryMusic
    ExplorerRootSection.VIDEOS -> Icons.Rounded.VideoLibrary
}
