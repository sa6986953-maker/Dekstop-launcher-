package com.example.ui.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.ui.graphics.ImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LauncherDatabase
import com.example.data.local.PinnedAppEntity
import com.example.data.local.SettingsDataStore
import com.example.data.model.AnimationSpeed
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.data.model.DesktopWindow
import com.example.data.model.ExplorerRootSection
import com.example.data.model.FileClipboard
import com.example.data.model.FileNode
import com.example.data.model.IconSizeOption
import com.example.data.model.InstalledApp
import com.example.data.model.PcSettingsState
import com.example.data.model.RecycleBinItem
import com.example.data.model.SafMount
import com.example.data.model.SystemStatus
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.ThemeMode
import com.example.data.model.WindowType
import com.example.data.repository.AppRepository
import com.example.data.repository.DesktopRepository
import com.example.data.repository.FileExplorerRepository
import com.example.data.repository.SystemMonitorRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

data class ExplorerUiState(
    val currentLocationLabel: String = "This PC",
    val currentPathOrUri: String? = null, // null == This PC root
    val currentIsSaf: Boolean = false,
    val breadcrumbs: List<Pair<String, String?>> = listOf("This PC" to null),
    val files: List<FileNode> = emptyList(),
    val searchQuery: String = "",
    val isGridView: Boolean = false,
    val isLoading: Boolean = false,
    val clipboard: FileClipboard? = null
)

data class NotepadState(
    val windowId: String,
    val title: String,
    val pathOrUri: String,
    val isSaf: Boolean,
    val content: String,
    val isDirty: Boolean = false
)

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val db = LauncherDatabase.getInstance(application)
    private val dao = db.launcherDao()
    private val settingsStore = SettingsDataStore(application)

    val appRepository = AppRepository(application, dao)
    private val desktopRepository = DesktopRepository(dao)
    val fileRepository = FileExplorerRepository(application, dao)
    val systemMonitor = SystemMonitorRepository(application)

    val settings: StateFlow<PcSettingsState> = settingsStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.Eagerly, PcSettingsState())

    val desktopItems: StateFlow<List<DesktopItem>> = desktopRepository.desktopItems
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recycleBinItems: StateFlow<List<RecycleBinItem>> = desktopRepository.recycleBinItems
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val installedApps: StateFlow<List<InstalledApp>> = appRepository.installedApps

    val pinnedApps: StateFlow<List<PinnedAppEntity>> = desktopRepository.pinnedApps
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val recentInstalledApps: StateFlow<List<InstalledApp>> = combine(
        desktopRepository.recentApps,
        appRepository.installedApps
    ) { recents, installed ->
        val byKey = installed.associateBy { it.componentKey }
        recents.mapNotNull { recent ->
            byKey[recent.componentKey]?.copy(lastLaunchTime = recent.lastLaunchedAt)
        }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val safMounts: StateFlow<List<SafMount>> = fileRepository.safMounts
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val systemStatus: StateFlow<SystemStatus> = systemMonitor.status

    private val _openWindows = MutableStateFlow<List<DesktopWindow>>(emptyList())
    val openWindows: StateFlow<List<DesktopWindow>> = _openWindows.asStateFlow()

    private val _activeWindowId = MutableStateFlow<String?>(null)
    val activeWindowId: StateFlow<String?> = _activeWindowId.asStateFlow()

    private val _startMenuOpen = MutableStateFlow(false)
    val startMenuOpen: StateFlow<Boolean> = _startMenuOpen.asStateFlow()

    private val _startMenuFocusSearch = MutableStateFlow(false)
    val startMenuFocusSearch: StateFlow<Boolean> = _startMenuFocusSearch.asStateFlow()

    private val _quickSettingsOpen = MutableStateFlow(false)
    val quickSettingsOpen: StateFlow<Boolean> = _quickSettingsOpen.asStateFlow()

    private val _calendarFlyoutOpen = MutableStateFlow(false)
    val calendarFlyoutOpen: StateFlow<Boolean> = _calendarFlyoutOpen.asStateFlow()

    private val _powerMenuOpen = MutableStateFlow(false)
    val powerMenuOpen: StateFlow<Boolean> = _powerMenuOpen.asStateFlow()

    private val _movingDesktopItemId = MutableStateFlow<String?>(null)
    val movingDesktopItemId: StateFlow<String?> = _movingDesktopItemId.asStateFlow()

    private val _explorerState = MutableStateFlow(ExplorerUiState())
    val explorerState: StateFlow<ExplorerUiState> = _explorerState.asStateFlow()

    private val _notepadSessions = MutableStateFlow<Map<String, NotepadState>>(emptyMap())
    val notepadSessions: StateFlow<Map<String, NotepadState>> = _notepadSessions.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private var nextZIndex = 10

    init {
        appRepository.startObservingPackages()
        systemMonitor.startMonitoring()

        viewModelScope.launch {
            fileRepository.ensureWorkspaceSeeded()
            appRepository.refreshInstalledApps()
            val apps = appRepository.installedApps.first { it.isNotEmpty() || true }
            desktopRepository.ensureSeeded(apps)
        }
    }

    override fun onCleared() {
        super.onCleared()
        appRepository.stopObservingPackages()
        systemMonitor.stopMonitoring()
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun showMessage(msg: String) {
        _statusMessage.value = msg
    }

    fun refreshSystemStatus() {
        systemMonitor.refreshAll()
    }

    fun refreshDesktopAndApps() {
        viewModelScope.launch {
            appRepository.refreshInstalledApps()
            systemMonitor.refreshAll()
            showMessage("Desktop and installed apps refreshed")
        }
    }

    fun onHomePressed() {
        _startMenuOpen.value = false
        _quickSettingsOpen.value = false
        _calendarFlyoutOpen.value = false
        _powerMenuOpen.value = false
        _movingDesktopItemId.value = null
    }

    fun closeAllFlyouts() {
        _startMenuOpen.value = false
        _startMenuFocusSearch.value = false
        _quickSettingsOpen.value = false
        _calendarFlyoutOpen.value = false
        _powerMenuOpen.value = false
    }

    fun toggleStartMenu(focusSearch: Boolean = false) {
        val next = if (focusSearch && _startMenuOpen.value && !_startMenuFocusSearch.value) true else !_startMenuOpen.value
        _quickSettingsOpen.value = false
        _calendarFlyoutOpen.value = false
        _powerMenuOpen.value = false
        _startMenuFocusSearch.value = focusSearch && next
        _startMenuOpen.value = next
    }

    fun toggleQuickSettings() {
        val next = !_quickSettingsOpen.value
        _startMenuOpen.value = false
        _calendarFlyoutOpen.value = false
        _powerMenuOpen.value = false
        _quickSettingsOpen.value = next
        if (next) systemMonitor.refreshAll()
    }

    fun toggleCalendarFlyout() {
        val next = !_calendarFlyoutOpen.value
        _startMenuOpen.value = false
        _quickSettingsOpen.value = false
        _powerMenuOpen.value = false
        _calendarFlyoutOpen.value = next
    }

    fun togglePowerMenu() {
        _powerMenuOpen.value = !_powerMenuOpen.value
    }

    // ---- App Launching & Icons ----
    suspend fun loadAppIcon(packageName: String, activityName: String): ImageBitmap? =
        appRepository.loadAppIcon(packageName, activityName)

    fun launchInstalledApp(app: InstalledApp) {
        closeAllFlyouts()
        viewModelScope.launch {
            val ok = appRepository.launchApp(
                packageName = app.packageName,
                activityName = app.activityName,
                preferFreeform = settings.value.preferFreeformLaunch
            )
            if (!ok) {
                showMessage("Unable to open ${app.label}")
            }
        }
    }

    fun launchPackageShortcut(packageName: String, activityName: String?, fallbackLabel: String) {
        closeAllFlyouts()
        viewModelScope.launch {
            val resolvedAct = activityName
                ?: installedApps.value.firstOrNull { it.packageName == packageName }?.activityName
            if (resolvedAct != null) {
                val ok = appRepository.launchApp(
                    packageName = packageName,
                    activityName = resolvedAct,
                    preferFreeform = settings.value.preferFreeformLaunch
                )
                if (!ok) showMessage("Could not launch $fallbackLabel")
            } else {
                showMessage("$fallbackLabel is no longer installed")
            }
        }
    }

    fun openAppInfo(packageName: String) {
        closeAllFlyouts()
        appRepository.openAppInfo(packageName)
    }

    fun openDefaultHomeSettings() {
        closeAllFlyouts()
        appRepository.openDefaultHomeSettings()
    }

    fun createRequestHomeRoleIntent(): Intent? = appRepository.createRequestHomeRoleIntent()

    fun openAndroidSystemSettings(action: String) {
        closeAllFlyouts()
        val intent = Intent(action).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
        val ok = runCatching {
            getApplication<Application>().startActivity(intent)
            true
        }.getOrDefault(false)
        if (!ok) {
            val fallback = Intent(Settings.ACTION_SETTINGS).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            runCatching { getApplication<Application>().startActivity(fallback) }
        }
    }

    // ---- Desktop Icons & Recycle Bin ----
    fun openDesktopItem(item: DesktopItem) {
        closeAllFlyouts()
        if (_movingDesktopItemId.value != null) {
            _movingDesktopItemId.value = null
            return
        }
        when (item.type) {
            DesktopItemType.THIS_PC -> openWindow(WindowType.FILE_EXPLORER, "This PC")
            DesktopItemType.PC_SETTINGS -> openWindow(WindowType.PC_SETTINGS, "PC Settings")
            DesktopItemType.RECYCLE_BIN -> openWindow(WindowType.RECYCLE_BIN, "Recycle Bin")
            DesktopItemType.TASK_MONITOR -> openWindow(WindowType.TASK_MONITOR, "Task Manager")
            DesktopItemType.FOLDER -> openWindow(WindowType.DESKTOP_FOLDER, item.title, folderId = item.id)
            DesktopItemType.FILE -> {
                val rel = item.targetPath ?: return
                val file = fileRepository.resolveRelativeWorkspaceFile(rel)
                if (file.exists()) {
                    openNotepadWindow(file.name, file.absolutePath, isSaf = false)
                } else {
                    openWindow(WindowType.FILE_EXPLORER, "File Explorer")
                }
            }
            DesktopItemType.APP_SHORTCUT -> {
                val pkg = item.targetPackage ?: return
                launchPackageShortcut(pkg, item.targetActivity, item.title)
            }
        }
    }

    fun startMovingDesktopItem(itemId: String) {
        _movingDesktopItemId.value = itemId
        showMessage("Tap any desktop cell to place icon")
    }

    fun cancelMovingDesktopItem() {
        _movingDesktopItemId.value = null
    }

    fun moveDesktopItemToGrid(itemId: String, col: Int, row: Int) {
        viewModelScope.launch {
            desktopRepository.moveDesktopItemToGrid(itemId, col, row)
            _movingDesktopItemId.value = null
        }
    }

    fun createDesktopFolder(name: String, parentFolderId: String? = null) {
        viewModelScope.launch {
            desktopRepository.createDesktopFolder(name, parentFolderId)
        }
    }

    fun createDesktopTextFile(name: String, parentFolderId: String? = null) {
        viewModelScope.launch {
            val clean = name.trim().ifEmpty { "New Note" }.let { if (it.contains('.')) it else "$it.txt" }
            val docsDir = fileRepository.getSectionPath(ExplorerRootSection.DOCUMENTS)
            fileRepository.createTextFile(docsDir, clean, "", isSaf = false).onSuccess { absPath ->
                val relPath = "Documents/${File(absPath).name}"
                desktopRepository.createDesktopFileShortcut(File(absPath).name, relPath, parentFolderId)
                openNotepadWindow(File(absPath).name, absPath, isSaf = false)
            }.onFailure {
                showMessage("Failed to create file: ${it.message}")
            }
        }
    }

    fun addAppToDesktop(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.addAppShortcutToDesktop(app)
            showMessage("Added ${app.label} to Desktop")
        }
    }

    fun renameDesktopItem(id: String, newTitle: String) {
        viewModelScope.launch {
            desktopRepository.renameDesktopItem(id, newTitle)
        }
    }

    fun autoArrangeDesktop(maxRows: Int = 6, sortByName: Boolean = false) {
        viewModelScope.launch {
            desktopRepository.autoArrangeDesktop(maxRows, sortByName)
            showMessage(if (sortByName) "Desktop icons sorted" else "Desktop icons arranged")
        }
    }

    fun moveDesktopItemToRecycleBin(item: DesktopItem) {
        viewModelScope.launch {
            desktopRepository.moveToRecycleBin(item)
            showMessage("Moved \"${item.title}\" to Recycle Bin")
        }
    }

    fun restoreFromRecycleBin(item: RecycleBinItem) {
        viewModelScope.launch {
            desktopRepository.restoreFromRecycleBin(item)
            showMessage("Restored \"${item.title}\" to Desktop")
        }
    }

    fun deletePermanentlyFromRecycleBin(id: String) {
        viewModelScope.launch {
            desktopRepository.deletePermanentlyFromRecycleBin(id)
        }
    }

    fun emptyRecycleBin() {
        viewModelScope.launch {
            desktopRepository.emptyRecycleBin()
            showMessage("Recycle Bin emptied")
        }
    }

    fun resetDefaultDesktopIcons() {
        viewModelScope.launch {
            desktopRepository.resetDefaultDesktop(installedApps.value)
            showMessage("Default desktop shortcuts restored")
        }
    }

    fun togglePinToStart(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.togglePinToStart(app)
        }
    }

    fun togglePinToTaskbar(app: InstalledApp) {
        viewModelScope.launch {
            desktopRepository.togglePinToTaskbar(app)
        }
    }

    // ---- Window Management ----
    fun openWindow(
        type: WindowType,
        title: String,
        folderId: String? = null,
        initialSection: ExplorerRootSection? = null
    ) {
        closeAllFlyouts()

        // Reuse singleton windows where appropriate
        val existing = _openWindows.value.firstOrNull { win ->
            when (type) {
                WindowType.PC_SETTINGS, WindowType.RECYCLE_BIN, WindowType.TASK_MONITOR -> win.type == type
                WindowType.DESKTOP_FOLDER -> win.type == type && win.folderId == folderId
                WindowType.FILE_EXPLORER -> win.type == type
                WindowType.NOTEPAD -> false
            }
        }

        if (existing != null) {
            focusWindow(existing.id)
            if (type == WindowType.FILE_EXPLORER && initialSection != null) {
                navigateExplorerToSection(initialSection)
            }
            return
        }

        val count = _openWindows.value.size
        val newId = "win_${type.name}_${UUID.randomUUID().toString().take(6)}"
        val defaultDims = when (type) {
            WindowType.FILE_EXPLORER -> 680f to 480f
            WindowType.PC_SETTINGS -> 660f to 490f
            WindowType.RECYCLE_BIN -> 560f to 420f
            WindowType.DESKTOP_FOLDER -> 520f to 400f
            WindowType.NOTEPAD -> 540f to 420f
            WindowType.TASK_MONITOR -> 580f to 440f
        }
        val window = DesktopWindow(
            id = newId,
            type = type,
            title = title,
            folderId = folderId,
            xOffsetDp = 18f + (count % 4) * 22f,
            yOffsetDp = 18f + (count % 4) * 22f,
            widthDp = defaultDims.first,
            heightDp = defaultDims.second,
            isMinimized = false,
            isMaximized = false,
            zIndex = ++nextZIndex
        )
        _openWindows.update { it + window }
        _activeWindowId.value = newId

        if (type == WindowType.FILE_EXPLORER) {
            if (initialSection != null) {
                navigateExplorerToSection(initialSection)
            } else {
                navigateExplorerToThisPc()
            }
        }
    }

    fun openNotepadWindow(title: String, pathOrUri: String, isSaf: Boolean) {
        closeAllFlyouts()
        val existingSession = _notepadSessions.value.values.firstOrNull { it.pathOrUri == pathOrUri }
        if (existingSession != null) {
            focusWindow(existingSession.windowId)
            return
        }

        viewModelScope.launch {
            val content = fileRepository.readTextFile(pathOrUri, isSaf).getOrElse {
                showMessage("Could not open $title: ${it.message}")
                return@launch
            }
            val winId = "win_NOTEPAD_${UUID.randomUUID().toString().take(6)}"
            val count = _openWindows.value.size
            val win = DesktopWindow(
                id = winId,
                type = WindowType.NOTEPAD,
                title = "$title - Notepad",
                fileUriOrPath = pathOrUri,
                xOffsetDp = 28f + (count % 4) * 20f,
                yOffsetDp = 28f + (count % 4) * 20f,
                widthDp = 540f,
                heightDp = 420f,
                zIndex = ++nextZIndex
            )
            _notepadSessions.update {
                it + (winId to NotepadState(winId, title, pathOrUri, isSaf, content, isDirty = false))
            }
            _openWindows.update { it + win }
            _activeWindowId.value = winId
        }
    }

    fun updateNotepadContent(windowId: String, newText: String) {
        _notepadSessions.update { map ->
            val current = map[windowId] ?: return@update map
            map + (windowId to current.copy(content = newText, isDirty = true))
        }
    }

    fun saveNotepad(windowId: String) {
        val session = _notepadSessions.value[windowId] ?: return
        viewModelScope.launch {
            fileRepository.writeTextFile(session.pathOrUri, session.content, session.isSaf)
                .onSuccess {
                    _notepadSessions.update { map ->
                        val cur = map[windowId] ?: return@update map
                        map + (windowId to cur.copy(isDirty = false))
                    }
                    showMessage("Saved ${session.title}")
                    refreshExplorerCurrentDir()
                }
                .onFailure {
                    showMessage("Save failed: ${it.message}")
                }
        }
    }

    fun focusWindow(windowId: String) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId) win.copy(isMinimized = false, zIndex = ++nextZIndex)
                else win
            }
        }
        _activeWindowId.value = windowId
    }

    fun toggleMinimizeFromTaskbar(windowId: String) {
        val target = _openWindows.value.firstOrNull { it.id == windowId } ?: return
        if (target.isMinimized || _activeWindowId.value != windowId) {
            focusWindow(windowId)
        } else {
            minimizeWindow(windowId)
        }
    }

    fun minimizeWindow(windowId: String) {
        _openWindows.update { list ->
            list.map { if (it.id == windowId) it.copy(isMinimized = true) else it }
        }
        if (_activeWindowId.value == windowId) {
            _activeWindowId.value = _openWindows.value
                .filter { it.id != windowId && !it.isMinimized }
                .maxByOrNull { it.zIndex }?.id
        }
    }

    fun toggleMaximizeWindow(windowId: String) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId) {
                    win.copy(isMaximized = !win.isMaximized, isMinimized = false, zIndex = ++nextZIndex)
                } else win
            }
        }
        _activeWindowId.value = windowId
    }

    fun moveWindow(windowId: String, dxDp: Float, dyDp: Float) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId && !win.isMaximized) {
                    win.copy(
                        xOffsetDp = (win.xOffsetDp + dxDp).coerceAtLeast(0f),
                        yOffsetDp = (win.yOffsetDp + dyDp).coerceAtLeast(0f)
                    )
                } else win
            }
        }
    }

    fun resizeWindow(windowId: String, dwDp: Float, dhDp: Float) {
        _openWindows.update { list ->
            list.map { win ->
                if (win.id == windowId && !win.isMaximized) {
                    win.copy(
                        widthDp = (win.widthDp + dwDp).coerceIn(300f, 1200f),
                        heightDp = (win.heightDp + dhDp).coerceIn(240f, 900f)
                    )
                } else win
            }
        }
    }

    fun closeWindow(windowId: String) {
        _openWindows.update { list -> list.filterNot { it.id == windowId } }
        _notepadSessions.update { it - windowId }
        if (_activeWindowId.value == windowId) {
            _activeWindowId.value = _openWindows.value.filterNot { it.isMinimized }.maxByOrNull { it.zIndex }?.id
        }
    }

    fun closeTopActiveWindowIfAny(): Boolean {
        val top = _openWindows.value.filterNot { it.isMinimized }.maxByOrNull { it.zIndex } ?: return false
        closeWindow(top.id)
        return true
    }

    // ---- File Explorer Navigation & Operations ----
    fun navigateExplorerToThisPc() {
        _explorerState.update {
            it.copy(
                currentLocationLabel = "This PC",
                currentPathOrUri = null,
                currentIsSaf = false,
                breadcrumbs = listOf("This PC" to null),
                files = emptyList(),
                isLoading = false
            )
        }
        systemMonitor.refreshClockAndMetrics()
    }

    fun navigateExplorerToSection(section: ExplorerRootSection) {
        if (section == ExplorerRootSection.THIS_PC) {
            navigateExplorerToThisPc()
            return
        }
        val path = fileRepository.getSectionPath(section)
        navigateExplorerToLocalPath(path, section.label)
    }

    fun navigateExplorerToLocalPath(path: String, labelOverride: String? = null) {
        viewModelScope.launch {
            _explorerState.update { it.copy(isLoading = true) }
            val files = fileRepository.listLocalDirectory(path)
            val rootPath = fileRepository.getWorkspaceRootPath()
            val rel = path.removePrefix(rootPath).trim('/')
            val crumbs = mutableListOf<Pair<String, String?>>("This PC" to null)
            if (rel.isNotEmpty()) {
                var accum = rootPath
                rel.split('/').forEach { seg ->
                    accum = "$accum/$seg"
                    crumbs.add(seg to accum)
                }
            }
            val label = labelOverride ?: File(path).name.ifEmpty { "Local Storage" }
            _explorerState.update {
                it.copy(
                    currentLocationLabel = label,
                    currentPathOrUri = path,
                    currentIsSaf = false,
                    breadcrumbs = crumbs,
                    files = files,
                    isLoading = false
                )
            }
        }
    }

    fun navigateExplorerToSafUri(uriString: String, label: String) {
        viewModelScope.launch {
            _explorerState.update { it.copy(isLoading = true) }
            val files = fileRepository.listSafDirectory(uriString)
            val existingCrumbs = _explorerState.value.breadcrumbs
            val updatedCrumbs = if (existingCrumbs.any { it.second == uriString }) {
                existingCrumbs.takeWhile { it.second != uriString } + (label to uriString)
            } else if (_explorerState.value.currentIsSaf) {
                existingCrumbs + (label to uriString)
            } else {
                listOf("This PC" to null, label to uriString)
            }
            _explorerState.update {
                it.copy(
                    currentLocationLabel = label,
                    currentPathOrUri = uriString,
                    currentIsSaf = true,
                    breadcrumbs = updatedCrumbs,
                    files = files,
                    isLoading = false
                )
            }
        }
    }

    fun navigateExplorerUp() {
        val crumbs = _explorerState.value.breadcrumbs
        if (crumbs.size <= 1) return
        val parent = crumbs[crumbs.size - 2]
        val parentPath = parent.second
        if (parentPath == null) {
            navigateExplorerToThisPc()
        } else if (parentPath.startsWith("content://")) {
            navigateExplorerToSafUri(parentPath, parent.first)
        } else {
            navigateExplorerToLocalPath(parentPath, parent.first)
        }
    }

    fun refreshExplorerCurrentDir() {
        val state = _explorerState.value
        val path = state.currentPathOrUri
        if (path == null) {
            systemMonitor.refreshClockAndMetrics()
        } else if (state.currentIsSaf) {
            navigateExplorerToSafUri(path, state.currentLocationLabel)
        } else {
            navigateExplorerToLocalPath(path, state.currentLocationLabel)
        }
    }

    fun setExplorerSearch(query: String) {
        _explorerState.update { it.copy(searchQuery = query) }
    }

    fun toggleExplorerViewMode() {
        _explorerState.update { it.copy(isGridView = !it.isGridView) }
    }

    fun mountSafTreeUri(uri: Uri) {
        viewModelScope.launch {
            fileRepository.addSafMount(uri)
                .onSuccess { mount ->
                    showMessage("Mounted \"${mount.displayName}\"")
                    navigateExplorerToSafUri(mount.treeUri, mount.displayName)
                }
                .onFailure {
                    showMessage("Could not mount folder: ${it.message}")
                }
        }
    }

    fun unmountSafDrive(mount: SafMount) {
        viewModelScope.launch {
            fileRepository.removeSafMount(mount)
            if (_explorerState.value.currentPathOrUri == mount.treeUri) {
                navigateExplorerToThisPc()
            }
            showMessage("Disconnected \"${mount.displayName}\"")
        }
    }

    fun openFileNode(node: FileNode) {
        if (node.isDirectory) {
            if (node.isSafDocument) {
                navigateExplorerToSafUri(node.pathOrUri, node.name)
            } else {
                navigateExplorerToLocalPath(node.pathOrUri, node.name)
            }
        } else if (fileRepository.isTextEditable(node.name, node.mimeType)) {
            openNotepadWindow(node.name, node.pathOrUri, node.isSafDocument)
        } else {
            fileRepository.openNodeExternally(node).onFailure {
                showMessage("No compatible Android app found for ${node.name}")
            }
        }
    }

    fun openFileNodeWithAndroidApp(node: FileNode) {
        if (node.isDirectory) return
        fileRepository.openNodeExternally(node).onFailure {
            showMessage("No compatible Android app found for ${node.name}")
        }
    }

    fun createFolderInExplorer(name: String) {
        val state = _explorerState.value
        val parent = state.currentPathOrUri ?: fileRepository.getSectionPath(ExplorerRootSection.DOCUMENTS)
        val isSaf = state.currentPathOrUri != null && state.currentIsSaf
        viewModelScope.launch {
            fileRepository.createFolder(parent, name, isSaf)
                .onSuccess {
                    refreshExplorerCurrentDir()
                    showMessage("Folder created")
                }
                .onFailure { showMessage(it.message ?: "Could not create folder") }
        }
    }

    fun createTextFileInExplorer(name: String) {
        val state = _explorerState.value
        val parent = state.currentPathOrUri ?: fileRepository.getSectionPath(ExplorerRootSection.DOCUMENTS)
        val isSaf = state.currentPathOrUri != null && state.currentIsSaf
        viewModelScope.launch {
            fileRepository.createTextFile(parent, name, "", isSaf)
                .onSuccess { path ->
                    refreshExplorerCurrentDir()
                    openNotepadWindow(name, path, isSaf)
                }
                .onFailure { showMessage(it.message ?: "Could not create file") }
        }
    }

    fun renameFileNode(node: FileNode, newName: String) {
        viewModelScope.launch {
            fileRepository.renameNode(node, newName)
                .onSuccess {
                    refreshExplorerCurrentDir()
                    showMessage("Renamed to $newName")
                }
                .onFailure { showMessage(it.message ?: "Rename failed") }
        }
    }

    fun deleteFileNode(node: FileNode) {
        viewModelScope.launch {
            fileRepository.deleteNode(node)
                .onSuccess {
                    refreshExplorerCurrentDir()
                    showMessage("Deleted ${node.name}")
                }
                .onFailure { showMessage(it.message ?: "Delete failed") }
        }
    }

    fun setExplorerClipboard(node: FileNode, isCut: Boolean) {
        _explorerState.update { it.copy(clipboard = FileClipboard(node, isCut)) }
        showMessage(if (isCut) "Cut \"${node.name}\"" else "Copied \"${node.name}\"")
    }

    fun pasteExplorerClipboard() {
        val state = _explorerState.value
        val clip = state.clipboard ?: return
        val destDir = state.currentPathOrUri ?: return
        viewModelScope.launch {
            fileRepository.copyOrMoveNode(clip.node, destDir, state.currentIsSaf, clip.isCut)
                .onSuccess {
                    if (clip.isCut) _explorerState.update { it.copy(clipboard = null) }
                    refreshExplorerCurrentDir()
                    showMessage(if (clip.isCut) "Moved ${clip.node.name}" else "Copied ${clip.node.name}")
                }
                .onFailure { showMessage(it.message ?: "Paste failed") }
        }
    }

    // ---- Hardware Controls ----
    fun setMediaVolumePercent(percent: Int) {
        systemMonitor.setMediaVolumePercent(percent)
    }

    fun toggleMute() {
        systemMonitor.toggleMute()
    }

    // ---- PC Settings Mutations ----
    fun updateThemeMode(mode: ThemeMode) = updateSettings { it.copy(themeMode = mode) }
    fun updateAccentKey(key: String) = updateSettings { it.copy(accentKey = key) }
    fun updateWallpaperPreset(id: String) = updateSettings { it.copy(wallpaperId = id, customWallpaperUri = null) }
    fun setCustomWallpaperUri(uri: String) = updateSettings { it.copy(customWallpaperUri = uri) }
    fun updateIconSize(size: IconSizeOption) = updateSettings { it.copy(iconSize = size) }
    fun setAutoArrangeGrid(enabled: Boolean) = updateSettings { it.copy(autoArrangeGrid = enabled) }
    fun setShowDesktopClock(show: Boolean) = updateSettings { it.copy(showDesktopClock = show) }
    fun setShowFileExtensions(show: Boolean) = updateSettings { it.copy(showFileExtensions = show) }
    fun updateTaskbarPosition(pos: TaskbarPosition) = updateSettings { it.copy(taskbarPosition = pos) }
    fun updateTaskbarSize(size: TaskbarSizeOption) = updateSettings { it.copy(taskbarSize = size) }
    fun updateTaskbarTransparency(alpha: Float) = updateSettings { it.copy(taskbarTransparency = alpha) }
    fun setShowTaskbarSearch(show: Boolean) = updateSettings { it.copy(showTaskbarSearch = show) }
    fun setAnimationsEnabled(enabled: Boolean) = updateSettings { it.copy(animationsEnabled = enabled) }
    fun updateAnimationSpeed(speed: AnimationSpeed) = updateSettings { it.copy(animationSpeed = speed) }
    fun setPreferFreeformLaunch(enabled: Boolean) = updateSettings { it.copy(preferFreeformLaunch = enabled) }
    fun setDefaultShortcut(slot: String, pkg: String?) = updateSettings {
        when (slot) {
            "browser" -> it.copy(defaultBrowserPackage = pkg)
            "files" -> it.copy(defaultFilesPackage = pkg)
            "gallery" -> it.copy(defaultGalleryPackage = pkg)
            "music" -> it.copy(defaultMusicPackage = pkg)
            else -> it
        }
    }

    private fun updateSettings(transform: (PcSettingsState) -> PcSettingsState) {
        viewModelScope.launch {
            settingsStore.update(transform)
        }
    }
}
