package com.example.data.repository

import android.app.ActivityOptions
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.data.local.LauncherDao
import com.example.data.local.RecentAppEntity
import com.example.data.model.InstalledApp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AppRepository(
    private val context: Context,
    private val dao: LauncherDao
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val iconCache = LruCache<String, ImageBitmap>(160)

    private val _installedApps = MutableStateFlow<List<InstalledApp>>(emptyList())
    val installedApps: StateFlow<List<InstalledApp>> = _installedApps.asStateFlow()

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context?, intent: Intent?) {
            scope.launch { refreshInstalledApps() }
        }
    }

    private var receiverRegistered = false

    fun startObservingPackages() {
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_PACKAGE_ADDED)
                addAction(Intent.ACTION_PACKAGE_REMOVED)
                addAction(Intent.ACTION_PACKAGE_CHANGED)
                addAction(Intent.ACTION_PACKAGE_REPLACED)
                addDataScheme("package")
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                context.registerReceiver(packageReceiver, filter, Context.RECEIVER_EXPORTED)
            } else {
                @Suppress("UnspecifiedRegisterReceiverFlag")
                context.registerReceiver(packageReceiver, filter)
            }
            receiverRegistered = true
        }
        scope.launch { refreshInstalledApps() }
    }

    fun stopObservingPackages() {
        if (receiverRegistered) {
            runCatching { context.unregisterReceiver(packageReceiver) }
            receiverRegistered = false
        }
    }

    suspend fun refreshInstalledApps() = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved: List<ResolveInfo> = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(mainIntent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(mainIntent, 0)
        }

        val selfPackage = context.packageName
        val apps = resolved
            .filter { it.activityInfo != null && it.activityInfo.packageName != selfPackage }
            .map { info ->
                val pkg = info.activityInfo.packageName
                val act = info.activityInfo.name
                val label = info.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg
                val appFlags = info.activityInfo.applicationInfo?.flags ?: 0
                val isSystem = (appFlags and ApplicationInfo.FLAG_SYSTEM) != 0
                InstalledApp(
                    packageName = pkg,
                    activityName = act,
                    label = label,
                    isSystemApp = isSystem
                )
            }
            .distinctBy { it.componentKey }
            .sortedBy { it.label.lowercase() }

        _installedApps.value = apps
    }

    suspend fun loadAppIcon(packageName: String, activityName: String): ImageBitmap? {
        val key = "$packageName/$activityName"
        iconCache.get(key)?.let { return it }

        return withContext(Dispatchers.IO) {
            runCatching {
                val pm = context.packageManager
                val component = ComponentName(packageName, activityName)
                val drawable = runCatching { pm.getActivityIcon(component) }.getOrElse {
                    pm.getApplicationIcon(packageName)
                }
                val bitmap = drawableToBitmap(drawable, 128)
                val imageBitmap = bitmap.asImageBitmap()
                iconCache.put(key, imageBitmap)
                imageBitmap
            }.getOrNull()
        }
    }

    suspend fun launchApp(
        packageName: String,
        activityName: String,
        preferFreeform: Boolean = false
    ): Boolean {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(packageName, activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        val launched = runCatching {
            if (preferFreeform && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N &&
                context.packageManager.hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)
            ) {
                val options = ActivityOptions.makeBasic().apply {
                    setLaunchBounds(Rect(120, 120, 1080, 960))
                }
                context.startActivity(intent, options.toBundle())
            } else {
                context.startActivity(intent)
            }
            true
        }.getOrElse {
            // Fallback: launch package default intent
            runCatching {
                val fallback = context.packageManager.getLaunchIntentForPackage(packageName)
                if (fallback != null) {
                    fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(fallback)
                    true
                } else {
                    false
                }
            }.getOrDefault(false)
        }

        if (launched) {
            dao.upsertRecentApp(
                RecentAppEntity(
                    componentKey = "$packageName/$activityName",
                    packageName = packageName,
                    activityName = activityName,
                    lastLaunchedAt = System.currentTimeMillis()
                )
            )
        }
        return launched
    }

    fun openAppInfo(packageName: String) {
        val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", packageName, null)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { context.startActivity(intent) }
    }

    fun openDefaultHomeSettings() {
        val homeSettingsIntent = Intent(Settings.ACTION_HOME_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val opened = runCatching {
            context.startActivity(homeSettingsIntent)
            true
        }.getOrDefault(false)

        if (!opened) {
            val fallback = Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            runCatching { context.startActivity(fallback) }
        }
    }

    fun createRequestHomeRoleIntent(): Intent? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val roleManager = context.getSystemService(RoleManager::class.java)
            if (roleManager != null &&
                roleManager.isRoleAvailable(RoleManager.ROLE_HOME) &&
                !roleManager.isRoleHeld(RoleManager.ROLE_HOME)
            ) {
                return roleManager.createRequestRoleIntent(RoleManager.ROLE_HOME)
            }
        }
        return null
    }

    private fun drawableToBitmap(drawable: Drawable, sizePx: Int): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            val bmp = drawable.bitmap
            if (bmp.width <= sizePx && bmp.height <= sizePx) return bmp
            return Bitmap.createScaledBitmap(bmp, sizePx, sizePx, true)
        }
        val width = drawable.intrinsicWidth.takeIf { it > 0 }?.coerceAtMost(sizePx) ?: sizePx
        val height = drawable.intrinsicHeight.takeIf { it > 0 }?.coerceAtMost(sizePx) ?: sizePx
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
