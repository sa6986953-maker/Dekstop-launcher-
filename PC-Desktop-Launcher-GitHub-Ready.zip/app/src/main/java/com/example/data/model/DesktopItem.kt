package com.example.data.model

import androidx.compose.runtime.Immutable

enum class DesktopItemType {
    THIS_PC,
    PC_SETTINGS,
    RECYCLE_BIN,
    TASK_MONITOR,
    FOLDER,
    FILE,
    APP_SHORTCUT
}

@Immutable
data class DesktopItem(
    val id: String,
    val title: String,
    val type: DesktopItemType,
    val targetPackage: String? = null,
    val targetActivity: String? = null,
    val targetPath: String? = null,
    val gridCol: Int = 0,
    val gridRow: Int = 0,
    val parentFolderId: String? = null,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Immutable
data class RecycleBinItem(
    val id: String,
    val originalItemId: String,
    val title: String,
    val type: DesktopItemType,
    val targetPackage: String? = null,
    val targetActivity: String? = null,
    val targetPath: String? = null,
    val originalLocation: String = "Desktop",
    val deletedAt: Long = System.currentTimeMillis()
)
