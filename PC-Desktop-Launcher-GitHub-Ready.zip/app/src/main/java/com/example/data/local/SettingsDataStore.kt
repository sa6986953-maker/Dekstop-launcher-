package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.AnimationSpeed
import com.example.data.model.IconSizeOption
import com.example.data.model.PcSettingsState
import com.example.data.model.TaskbarPosition
import com.example.data.model.TaskbarSizeOption
import com.example.data.model.ThemeMode
import com.example.data.model.WallpaperPreset
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.pcSettingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "pc_launcher_settings")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val ACCENT_KEY = stringPreferencesKey("accent_key")
        val WALLPAPER_ID = stringPreferencesKey("wallpaper_id")
        val CUSTOM_WALLPAPER_URI = stringPreferencesKey("custom_wallpaper_uri")
        val ICON_SIZE = stringPreferencesKey("icon_size")
        val AUTO_ARRANGE_GRID = booleanPreferencesKey("auto_arrange_grid")
        val SHOW_DESKTOP_CLOCK = booleanPreferencesKey("show_desktop_clock")
        val SHOW_FILE_EXTENSIONS = booleanPreferencesKey("show_file_extensions")
        val TASKBAR_POSITION = stringPreferencesKey("taskbar_position")
        val TASKBAR_SIZE = stringPreferencesKey("taskbar_size")
        val TASKBAR_TRANSPARENCY = floatPreferencesKey("taskbar_transparency")
        val SHOW_TASKBAR_SEARCH = booleanPreferencesKey("show_taskbar_search")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val ANIMATION_SPEED = stringPreferencesKey("animation_speed")
        val PREFER_FREEFORM_LAUNCH = booleanPreferencesKey("prefer_freeform_launch")
        val DEFAULT_BROWSER_PKG = stringPreferencesKey("default_browser_pkg")
        val DEFAULT_FILES_PKG = stringPreferencesKey("default_files_pkg")
        val DEFAULT_GALLERY_PKG = stringPreferencesKey("default_gallery_pkg")
        val DEFAULT_MUSIC_PKG = stringPreferencesKey("default_music_pkg")
    }

    val settingsFlow: Flow<PcSettingsState> = context.pcSettingsDataStore.data.map { prefs ->
        PcSettingsState(
            themeMode = prefs[Keys.THEME_MODE]?.let { name ->
                ThemeMode.entries.firstOrNull { it.name == name }
            } ?: ThemeMode.DARK,
            accentKey = prefs[Keys.ACCENT_KEY] ?: "blue",
            wallpaperId = prefs[Keys.WALLPAPER_ID] ?: WallpaperPreset.BLOOM.id,
            customWallpaperUri = prefs[Keys.CUSTOM_WALLPAPER_URI],
            iconSize = prefs[Keys.ICON_SIZE]?.let { name ->
                IconSizeOption.entries.firstOrNull { it.name == name }
            } ?: IconSizeOption.MEDIUM,
            autoArrangeGrid = prefs[Keys.AUTO_ARRANGE_GRID] ?: true,
            showDesktopClock = prefs[Keys.SHOW_DESKTOP_CLOCK] ?: true,
            showFileExtensions = prefs[Keys.SHOW_FILE_EXTENSIONS] ?: true,
            taskbarPosition = prefs[Keys.TASKBAR_POSITION]?.let { name ->
                TaskbarPosition.entries.firstOrNull { it.name == name }
            } ?: TaskbarPosition.BOTTOM,
            taskbarSize = prefs[Keys.TASKBAR_SIZE]?.let { name ->
                TaskbarSizeOption.entries.firstOrNull { it.name == name }
            } ?: TaskbarSizeOption.STANDARD,
            taskbarTransparency = (prefs[Keys.TASKBAR_TRANSPARENCY] ?: 0.84f).coerceIn(0.35f, 0.98f),
            showTaskbarSearch = prefs[Keys.SHOW_TASKBAR_SEARCH] ?: true,
            animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
            animationSpeed = prefs[Keys.ANIMATION_SPEED]?.let { name ->
                AnimationSpeed.entries.firstOrNull { it.name == name }
            } ?: AnimationSpeed.STANDARD,
            preferFreeformLaunch = prefs[Keys.PREFER_FREEFORM_LAUNCH] ?: false,
            defaultBrowserPackage = prefs[Keys.DEFAULT_BROWSER_PKG],
            defaultFilesPackage = prefs[Keys.DEFAULT_FILES_PKG],
            defaultGalleryPackage = prefs[Keys.DEFAULT_GALLERY_PKG],
            defaultMusicPackage = prefs[Keys.DEFAULT_MUSIC_PKG]
        )
    }

    suspend fun update(transform: (PcSettingsState) -> PcSettingsState) {
        context.pcSettingsDataStore.edit { prefs ->
            val current = PcSettingsState(
                themeMode = prefs[Keys.THEME_MODE]?.let { n -> ThemeMode.entries.firstOrNull { it.name == n } } ?: ThemeMode.DARK,
                accentKey = prefs[Keys.ACCENT_KEY] ?: "blue",
                wallpaperId = prefs[Keys.WALLPAPER_ID] ?: WallpaperPreset.BLOOM.id,
                customWallpaperUri = prefs[Keys.CUSTOM_WALLPAPER_URI],
                iconSize = prefs[Keys.ICON_SIZE]?.let { n -> IconSizeOption.entries.firstOrNull { it.name == n } } ?: IconSizeOption.MEDIUM,
                autoArrangeGrid = prefs[Keys.AUTO_ARRANGE_GRID] ?: true,
                showDesktopClock = prefs[Keys.SHOW_DESKTOP_CLOCK] ?: true,
                showFileExtensions = prefs[Keys.SHOW_FILE_EXTENSIONS] ?: true,
                taskbarPosition = prefs[Keys.TASKBAR_POSITION]?.let { n -> TaskbarPosition.entries.firstOrNull { it.name == n } } ?: TaskbarPosition.BOTTOM,
                taskbarSize = prefs[Keys.TASKBAR_SIZE]?.let { n -> TaskbarSizeOption.entries.firstOrNull { it.name == n } } ?: TaskbarSizeOption.STANDARD,
                taskbarTransparency = prefs[Keys.TASKBAR_TRANSPARENCY] ?: 0.84f,
                showTaskbarSearch = prefs[Keys.SHOW_TASKBAR_SEARCH] ?: true,
                animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
                animationSpeed = prefs[Keys.ANIMATION_SPEED]?.let { n -> AnimationSpeed.entries.firstOrNull { it.name == n } } ?: AnimationSpeed.STANDARD,
                preferFreeformLaunch = prefs[Keys.PREFER_FREEFORM_LAUNCH] ?: false,
                defaultBrowserPackage = prefs[Keys.DEFAULT_BROWSER_PKG],
                defaultFilesPackage = prefs[Keys.DEFAULT_FILES_PKG],
                defaultGalleryPackage = prefs[Keys.DEFAULT_GALLERY_PKG],
                defaultMusicPackage = prefs[Keys.DEFAULT_MUSIC_PKG]
            )
            val next = transform(current)
            prefs[Keys.THEME_MODE] = next.themeMode.name
            prefs[Keys.ACCENT_KEY] = next.accentKey
            prefs[Keys.WALLPAPER_ID] = next.wallpaperId
            if (next.customWallpaperUri != null) {
                prefs[Keys.CUSTOM_WALLPAPER_URI] = next.customWallpaperUri
            } else {
                prefs.remove(Keys.CUSTOM_WALLPAPER_URI)
            }
            prefs[Keys.ICON_SIZE] = next.iconSize.name
            prefs[Keys.AUTO_ARRANGE_GRID] = next.autoArrangeGrid
            prefs[Keys.SHOW_DESKTOP_CLOCK] = next.showDesktopClock
            prefs[Keys.SHOW_FILE_EXTENSIONS] = next.showFileExtensions
            prefs[Keys.TASKBAR_POSITION] = next.taskbarPosition.name
            prefs[Keys.TASKBAR_SIZE] = next.taskbarSize.name
            prefs[Keys.TASKBAR_TRANSPARENCY] = next.taskbarTransparency
            prefs[Keys.SHOW_TASKBAR_SEARCH] = next.showTaskbarSearch
            prefs[Keys.ANIMATIONS_ENABLED] = next.animationsEnabled
            prefs[Keys.ANIMATION_SPEED] = next.animationSpeed.name
            prefs[Keys.PREFER_FREEFORM_LAUNCH] = next.preferFreeformLaunch
            if (next.defaultBrowserPackage != null) prefs[Keys.DEFAULT_BROWSER_PKG] = next.defaultBrowserPackage else prefs.remove(Keys.DEFAULT_BROWSER_PKG)
            if (next.defaultFilesPackage != null) prefs[Keys.DEFAULT_FILES_PKG] = next.defaultFilesPackage else prefs.remove(Keys.DEFAULT_FILES_PKG)
            if (next.defaultGalleryPackage != null) prefs[Keys.DEFAULT_GALLERY_PKG] = next.defaultGalleryPackage else prefs.remove(Keys.DEFAULT_GALLERY_PKG)
            if (next.defaultMusicPackage != null) prefs[Keys.DEFAULT_MUSIC_PKG] = next.defaultMusicPackage else prefs.remove(Keys.DEFAULT_MUSIC_PKG)
        }
    }
}
