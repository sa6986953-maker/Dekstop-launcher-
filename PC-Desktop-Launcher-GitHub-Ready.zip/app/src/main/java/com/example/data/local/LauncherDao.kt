package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface LauncherDao {

    @Query("SELECT * FROM desktop_items ORDER BY sortOrder ASC, createdAt ASC")
    fun observeDesktopItems(): Flow<List<DesktopItemEntity>>

    @Query("SELECT * FROM desktop_items ORDER BY sortOrder ASC, createdAt ASC")
    suspend fun getDesktopItemsOnce(): List<DesktopItemEntity>

    @Query("SELECT COUNT(*) FROM desktop_items")
    suspend fun countDesktopItems(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDesktopItem(item: DesktopItemEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertDesktopItems(items: List<DesktopItemEntity>)

    @Update
    suspend fun updateDesktopItem(item: DesktopItemEntity)

    @Query("DELETE FROM desktop_items WHERE id = :id")
    suspend fun deleteDesktopItemById(id: String)

    @Query("DELETE FROM desktop_items")
    suspend fun clearAllDesktopItems()

    @Query("SELECT * FROM recycle_bin_items ORDER BY deletedAt DESC")
    fun observeRecycleBin(): Flow<List<RecycleBinEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecycleBinItem(item: RecycleBinEntity)

    @Query("DELETE FROM recycle_bin_items WHERE id = :id")
    suspend fun deleteRecycleBinItemById(id: String)

    @Query("DELETE FROM recycle_bin_items")
    suspend fun emptyRecycleBin()

    @Query("SELECT * FROM pinned_apps ORDER BY sortOrder ASC")
    fun observePinnedApps(): Flow<List<PinnedAppEntity>>

    @Query("SELECT * FROM pinned_apps WHERE componentKey = :key LIMIT 1")
    suspend fun getPinnedApp(key: String): PinnedAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertPinnedApp(item: PinnedAppEntity)

    @Query("DELETE FROM pinned_apps WHERE componentKey = :key")
    suspend fun deletePinnedApp(key: String)

    @Query("SELECT * FROM recent_apps ORDER BY lastLaunchedAt DESC LIMIT 12")
    fun observeRecentApps(): Flow<List<RecentAppEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertRecentApp(item: RecentAppEntity)

    @Query("SELECT * FROM saf_mounts ORDER BY addedAt DESC")
    fun observeSafMounts(): Flow<List<SafMountEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSafMount(mount: SafMountEntity)

    @Query("DELETE FROM saf_mounts WHERE id = :id")
    suspend fun deleteSafMount(id: String)
}
