package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.DesktopItem
import com.example.data.model.DesktopItemType
import com.example.data.model.RecycleBinItem
import com.example.data.model.SafMount

@Entity(tableName = "desktop_items")
data class DesktopItemEntity(
    @PrimaryKey val id: String,
    val title: String,
    val type: String,
    val targetPackage: String? = null,
    val targetActivity: String? = null,
    val targetPath: String? = null,
    val gridCol: Int = 0,
    val gridRow: Int = 0,
    val parentFolderId: String? = null,
    val sortOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): DesktopItem = DesktopItem(
        id = id,
        title = title,
        type = DesktopItemType.entries.firstOrNull { it.name == type } ?: DesktopItemType.FILE,
        targetPackage = targetPackage,
        targetActivity = targetActivity,
        targetPath = targetPath,
        gridCol = gridCol,
        gridRow = gridRow,
        parentFolderId = parentFolderId,
        sortOrder = sortOrder,
        createdAt = createdAt
    )

    companion object {
        fun fromDomain(item: DesktopItem): DesktopItemEntity = DesktopItemEntity(
            id = item.id,
            title = item.title,
            type = item.type.name,
            targetPackage = item.targetPackage,
            targetActivity = item.targetActivity,
            targetPath = item.targetPath,
            gridCol = item.gridCol,
            gridRow = item.gridRow,
            parentFolderId = item.parentFolderId,
            sortOrder = item.sortOrder,
            createdAt = item.createdAt
        )
    }
}

@Entity(tableName = "recycle_bin_items")
data class RecycleBinEntity(
    @PrimaryKey val id: String,
    val originalItemId: String,
    val title: String,
    val type: String,
    val targetPackage: String? = null,
    val targetActivity: String? = null,
    val targetPath: String? = null,
    val originalLocation: String = "Desktop",
    val deletedAt: Long = System.currentTimeMillis()
) {
    fun toDomain(): RecycleBinItem = RecycleBinItem(
        id = id,
        originalItemId = originalItemId,
        title = title,
        type = DesktopItemType.entries.firstOrNull { it.name == type } ?: DesktopItemType.FILE,
        targetPackage = targetPackage,
        targetActivity = targetActivity,
        targetPath = targetPath,
        originalLocation = originalLocation,
        deletedAt = deletedAt
    )
}

@Entity(tableName = "pinned_apps")
data class PinnedAppEntity(
    @PrimaryKey val componentKey: String,
    val packageName: String,
    val activityName: String,
    val label: String,
    val pinnedToTaskbar: Boolean = false,
    val pinnedToStart: Boolean = true,
    val sortOrder: Int = 0
)

@Entity(tableName = "recent_apps")
data class RecentAppEntity(
    @PrimaryKey val componentKey: String,
    val packageName: String,
    val activityName: String,
    val lastLaunchedAt: Long
)

@Entity(tableName = "saf_mounts")
data class SafMountEntity(
    @PrimaryKey val id: String,
    val treeUri: String,
    val displayName: String,
    val addedAt: Long
) {
    fun toDomain(): SafMount = SafMount(
        id = id,
        treeUri = treeUri,
        displayName = displayName,
        addedAt = addedAt
    )
}
