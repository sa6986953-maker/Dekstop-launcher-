package com.example.data.model

import androidx.compose.runtime.Immutable

enum class ThemeMode(val label: String) {
    SYSTEM("Follow Android System"),
    DARK("Dark Mode"),
    LIGHT("Light Mode")
}

enum class IconSizeOption(val label: String, val tileWidthDp: Int, val iconDp: Int, val fontSp: Int) {
    SMALL("Small", 76, 36, 11),
    MEDIUM("Medium", 88, 44, 12),
    LARGE("Large", 104, 54, 13)
}

enum class TaskbarPosition(val label: String) {
    BOTTOM("Bottom"),
    TOP("Top")
}

enum class TaskbarSizeOption(val label: String, val heightDp: Int, val iconDp: Int) {
    COMPACT("Compact", 46, 20),
    STANDARD("Standard", 54, 24),
    LARGE("Large", 64, 28)
}

enum class AnimationSpeed(val label: String, val durationMs: Int) {
    SNAPPY("Snappy (120ms)", 120),
    STANDARD("Standard (220ms)", 220),
    SMOOTH("Smooth (320ms)", 320)
}

enum class WallpaperPreset(val id: String, val title: String, val isLight: Boolean) {
    BLOOM("bloom", "Windows Bloom", false),
    SUNRISE("sunrise", "Pearl Sunrise", true),
    AURORA("aurora", "Northern Aurora", false),
    SUNSET("sunset", "Dusk Dunes", false),
    MIDNIGHT_MESH("midnight", "Midnight Carbon", false),
    OCEAN_GLASS("ocean", "Azure Gradient", false)
}

@Immutable
data class PcSettingsState(
    val themeMode: ThemeMode = ThemeMode.DARK,
    val accentKey: String = "blue",
    val wallpaperId: String = WallpaperPreset.BLOOM.id,
    val customWallpaperUri: String? = null,
    val iconSize: IconSizeOption = IconSizeOption.MEDIUM,
    val autoArrangeGrid: Boolean = true,
    val showDesktopClock: Boolean = true,
    val showFileExtensions: Boolean = true,
    val taskbarPosition: TaskbarPosition = TaskbarPosition.BOTTOM,
    val taskbarSize: TaskbarSizeOption = TaskbarSizeOption.STANDARD,
    val taskbarTransparency: Float = 0.82f,
    val showTaskbarSearch: Boolean = true,
    val animationsEnabled: Boolean = true,
    val animationSpeed: AnimationSpeed = AnimationSpeed.STANDARD,
    val preferFreeformLaunch: Boolean = false,
    val defaultBrowserPackage: String? = null,
    val defaultFilesPackage: String? = null,
    val defaultGalleryPackage: String? = null,
    val defaultMusicPackage: String? = null
)
