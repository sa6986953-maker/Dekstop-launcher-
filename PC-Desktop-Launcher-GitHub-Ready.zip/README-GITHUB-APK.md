# PC Desktop Launcher — GitHub APK Build

This is an Android Gradle project. GitHub Actions builds a **debug APK** automatically.

## Build on GitHub

1. Create a new GitHub repository.
2. Upload the **contents of this ZIP** to the repository root (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and click **Run workflow**, or push to `main` / `master`.
5. When the workflow finishes successfully, open its run.
6. Under **Artifacts**, download `PC-Desktop-Launcher-debug-apk`.
7. Extract the downloaded artifact ZIP to get the `.apk` file.

## Notes

- No `google-services.json`, Firebase configuration, API key, or release keystore is included. The current Gradle configuration treats missing Google Services configuration as a warning.
- The workflow creates an installable **debug APK**, signed with the standard Android debug key.
- This is not a Play Store release build. A release APK requires a private signing keystore and credentials configured securely as GitHub repository secrets.
- Do not upload passwords, API keys, `.env` files, or signing keystores to a public repository.
